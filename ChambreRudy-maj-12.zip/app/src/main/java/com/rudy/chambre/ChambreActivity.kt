package com.rudy.chambre

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.TextureView
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * La chambre.
 *
 * Le decor et ses objets sont dessines par [VueChambre], en natif. Les jeux,
 * les vitrines et l'atelier restent des pages : ils s'ouvrent par-dessus,
 * dans [PageActivity], au moment ou on les demande.
 */
class ChambreActivity : ComponentActivity() {

    private lateinit var vue: VueChambre
    private lateinit var son: SonChambre
    private lateinit var etiquette: TextView
    private lateinit var ecranTele: TextureView
    private var lecteur: android.media.MediaPlayer? = null

    override fun onCreate(etat: Bundle?) {
        super.onCreate(etat)
        try {
            demarrer(etat)
        } catch (e: Throwable) {
            // Plutot que de se fermer sans rien dire, la chambre affiche ce qui
            // a echoue : la ligne exacte est alors lisible a l'ecran.
            afficherLeSouci(e)
        }
    }

    /** L'ecran de secours : le detail de l'erreur, et de quoi le recopier. */
    private fun afficherLeSouci(e: Throwable) {
        val texte = StringBuilder("La chambre n'a pas pu démarrer.\n\n")
        texte.append(e.toString()).append('\n')
        for (ligne in e.stackTrace.take(12))
            if (ligne.className.startsWith("com.rudy")) texte.append("  ").append(ligne).append('\n')
        try {
            java.io.File(filesDir, "dernier_plantage.txt").writeText(texte.toString())
        } catch (_: Throwable) {}
        val vueTexte = TextView(this).apply {
            setTextColor(0xFFFFD9D2.toInt())
            setBackgroundColor(0xFF1A0E0E.toInt())
            textSize = 12f
            setPadding(36, 90, 36, 36)
            setTextIsSelectable(true)
            text = texte.toString()
        }
        setContentView(android.widget.ScrollView(this).apply { addView(vueTexte) })
    }

    /** Le vrai demarrage, appele a l'abri. */
    private fun demarrer(etat: Bundle?) {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        son = SonChambre(this)
        SonPartage.radio = son

        vue = VueChambre(this)
        vue.surObjet = { quoi -> toucheObjet(quoi) }
        // la fleche du lit : seulement quand aucune fille n'est a la maison
        vue.litLibre = { calque == null && Visite.ici(this).isEmpty() }
        vue.surEcranTele = { r -> placerEcranTele(r) }
        vue.surCamera = { m, l, t, w, h -> cameraVisite(m, l, t, w, h) }
        // le bouton de la radio regle vraiment le volume de la musique
        vue.surVolume = { v -> son.majVolume(v) }

        etiquette = TextView(this).apply {
            setTextColor(0xFFFFEEC2.toInt())
            textSize = 13f
            setPadding(28, 28, 28, 28)
            alpha = 0f
        }

        vue.surEtapeIntro = { quoi ->
            when (quoi) {
                "debut" -> {                      // la radio joue des la premiere image
                    son.radio()
                    vue.radioAllumee = son.allumee()
                }
                "ouverture" -> son.bruit("carton.mp3")
                "chambre" -> {
                    son.bruit("pose.mp3")
                    vue.cadrerSurLaTele()
                    boutonTelephone?.visibility = View.VISIBLE   // le téléphone apparaît avec la chambre
                }
            }
        }

        // l'ecran de la tele : une surface posee sur le decor, a sa place exacte
        ecranTele = TextureView(this).apply { alpha = 0f; isOpaque = false }

        val racine = FrameLayout(this)
        racineChambre = racine
        posePorteMonnaie(racine)
        racine.addView(vue, FrameLayout.LayoutParams(-1, -1))
        racine.addView(ecranTele, FrameLayout.LayoutParams(1, 1))
        racine.addView(etiquette, FrameLayout.LayoutParams(-2, -2))
        poseTelephone(racine)
        setContentView(racine)

        // « Bureau » depuis un emulateur doit revenir immediatement a la
        // chambre utile (TV, tiroirs et consoles), jamais a l'introduction.
        val retourBureau = intent.getBooleanExtra("retour_bureau", false)
        if (etat == null && !retourBureau) Visite.partie(this)
        if (retourBureau || etat != null) boutonTelephone?.visibility = View.VISIBLE
        if (retourBureau) {
            vue.post { vue.cadrerSurLaTele() }
        } else if (etat == null) {
            // l'ouverture du carton, une seule fois par lancement
            vue.post { vue.jouerIntro() }
        }
        // la premiere console est prete avant meme qu'on touche le carton
        vue.postDelayed({ preparerVideo(Decor.CONSOLES[0]) }, 1200)
    }

    /**
     * Le choix d'une video, avec la telecommande.
     *
     * On ouvre le selecteur du telephone ; ce qu'il rend est joue sur l'ecran
     * de la tele, a la place des sequences de consoles.
     */
    private val choisirUneVideo =
        registerForActivityResult(
            androidx.activity.result.contract.ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@registerForActivityResult
            try {
                contentResolver.takePersistableUriPermission(
                    uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Throwable) {}
            jouerSurLaTele(uri)
        }

    /** Joue une video du telephone sur l'ecran de la tele. */
    private fun jouerSurLaTele(uri: android.net.Uri) {
        couperYoutube()
        teleAllumee = true
        ecranTele.alpha = 1f
        placerEcranTele(vue.rectangleTele())
        val surface = ecranTele.surfaceTexture ?: return
        try { lecteur?.release() } catch (_: Throwable) {}
        lecteur = null
        try {
            lecteur = android.media.MediaPlayer().apply {
                setDataSource(this@ChambreActivity, uri)
                setSurface(surfaceDeLaTele(surface))
                setVolume(0.9f, 0.9f)
                setOnCompletionListener {
                    teleAllumee = false
                    ecranTele.animate().alpha(0f).setDuration(600).start()
                    son.enPause(false)
                }
                prepare()
                start()
            }
            son.enPause(true)        // la radio se tait pendant la video
            dire("lecture sur la télé")
        } catch (_: Throwable) {
            teleAllumee = false
            ecranTele.alpha = 0f
            dire("cette vidéo ne peut pas être lue")
        }
    }

    /** Un menu sombre, lisible par-dessus le decor. */
    private fun menu(): AlertDialog.Builder =
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)

    private fun dire(texte: String) {
        etiquette.text = texte
        etiquette.animate().alpha(1f).setDuration(160).withEndAction {
            etiquette.animate().alpha(0f).setStartDelay(1600).setDuration(400).start()
        }.start()
    }

    // ================= ce qu'on touche =================

    private fun toucheObjet(quoi: String) {
        when (quoi) {
            "carton" -> {
                son.bruit("carton.mp3")
                // la console met plus d'une seconde a sortir : on prepare sa
                // video pendant ce temps, elle demarre alors a l'instant meme
                preparerVideo(vue.consoleAVenir())
                vue.consoleSuivante { console ->
                    if (console == null) {
                        // la 3DS vient de rentrer : le carton est vide, la
                        // tele s'eteint. Un nouvel appui fera ressortir la NES.
                        eteindreLaTele()
                        dire("tout est rangé dans le carton")
                        vue.postDelayed({ preparerVideo(Decor.CONSOLES[0]) }, 400)
                        return@consoleSuivante
                    }
                    son.bruit("pose.mp3")
                    dire(console.nom)
                    allumerLaTele(console)
                    // et on prepare deja celle d'apres
                    val i = Decor.CONSOLES.indexOf(console) + 1
                    if (i < Decor.CONSOLES.size) {
                        vue.postDelayed({ preparerVideo(Decor.CONSOLES[i]) }, 900)
                    }
                }
            }
            "radio" -> {
                val morceau = son.radio()
                vue.radioAllumee = son.allumee()
                vue.invalidate()
                dire(morceau.ifEmpty { "radio éteinte" })
            }
            "tiroir" -> {
                son.bruit("tiroir.mp3")
                val ouvrir = vue.tiroir < 0.5f
                vue.ouvrirTiroir(ouvrir) { if (ouvrir) proposerTiroir() }
            }
            // le second tiroir, en bas a droite : meme bruit, meme geste
            "tiroir2" -> {
                son.bruit("tiroir.mp3")
                val ouvrir = vue.tiroir2 < 0.5f
                vue.ouvrirTiroir2(ouvrir)
            }
            /*
             * La telecommande.
             *
             * Elle ne sert que si le bureau est libre : tant qu'une console
             * est posee, la tele lui appartient.
             */
            /*
             * La loupe : elle montre de pres la console posee sur le bureau.
             * Sans console sur le bureau, elle ne sert a rien.
             */
            "loupe" -> {
                val console = vue.consolePosee()
                when {
                    console == null -> dire("posez d'abord une console")
                    com.rudy.chambre.loupe.Loupe.aUnePage(console.id) -> {
                        son.bruit("pose.mp3")
                        com.rudy.chambre.loupe.Loupe.ouvrir(this, console.id)
                    }
                    else -> dire("pas encore de loupe pour la " + console.nom)
                }
            }
            "telecommande" -> {
                if (vue.consolePosee() != null) {
                    dire("veuillez d'abord ranger la console")
                } else {
                    son.bruit("pose.mp3")
                    menuTelecommande()
                }
            }
            "porteG" -> {
                val ouvrir = vue.porteG < 0.5f
                son.bruit(if (ouvrir) "porte_ouvre.mp3" else "porte_ferme.mp3")
                vue.bougerPorte(true, ouvrir) { if (ouvrir) menuJeuxDeSociete() }
            }
            "porteD" -> {
                val ouvrir = vue.porteD < 0.5f
                son.bruit(if (ouvrir) "porte_ouvre.mp3" else "porte_ferme.mp3")
                vue.bougerPorte(false, ouvrir) { if (ouvrir) ouvrirVitrine() }
            }
            "tele" -> vue.consolePosee()?.let { dire(it.nom) }
            "teleLong" -> montrerAssemblage()
            "serrure" -> if (calque != null) calque?.evaluateJavascript("window.retourDemande&&window.retourDemande()", null) else menuDehors()
            "livre" -> startActivity(Intent(this,
                com.rudy.chambre.livre.LivreActivity::class.java))
            "lit" -> if (calque == null && Visite.ici(this).isEmpty())
                confirmer("Voulez-vous dormir ?") { page("jeux/dreamtosleep.html", "DreamtoSleep", paysage = true) }
        }
    }

    /**
     * L'ecran de la tele suit le decor.
     *
     * La video est une surface posee sur la vue : elle ne se deplace pas toute
     * seule quand la camera tourne. On la replace donc a chaque image, et on
     * l'efface des qu'on regarde un autre mur.
     */
    private fun placerEcranTele(r: android.graphics.RectF?) {
        if (!::ecranTele.isInitialized) return
        val tw = teleWeb
        if (r == null || !teleAllumee) {
            ecranTele.visibility = android.view.View.INVISIBLE
            tw?.visibility = android.view.View.INVISIBLE
            return
        }
        val lp = ecranTele.layoutParams as? FrameLayout.LayoutParams ?: return
        val l = r.width().toInt(); val h = r.height().toInt()
        if (l <= 0 || h <= 0) {
            ecranTele.visibility = android.view.View.INVISIBLE
            tw?.visibility = android.view.View.INVISIBLE
            return
        }
        if (lp.width != l || lp.height != h || lp.leftMargin != r.left.toInt()
            || lp.topMargin != r.top.toInt()) {
            lp.width = l; lp.height = h
            lp.leftMargin = r.left.toInt(); lp.topMargin = r.top.toInt()
            ecranTele.layoutParams = lp
        }
        ecranTele.visibility = android.view.View.VISIBLE
        if (tw != null) {
            if (youtubeAllume) {
                val lw = tw.layoutParams as? FrameLayout.LayoutParams
                if (lw != null && (lw.width != l || lw.height != h || lw.leftMargin != r.left.toInt()
                        || lw.topMargin != r.top.toInt())) {
                    lw.width = l; lw.height = h
                    lw.leftMargin = r.left.toInt(); lw.topMargin = r.top.toInt()
                    tw.layoutParams = lw
                }
                tw.visibility = android.view.View.VISIBLE
            } else tw.visibility = android.view.View.INVISIBLE
        }
    }

    // ==================== L'argent, en haut a droite ====================
    private var montantArgent: TextView? = null

    /** Le petit bandeau « billets + montant », tout en haut a droite de la chambre. */
    private fun posePorteMonnaie(racine: FrameLayout) {
        val dens = resources.displayMetrics.density
        fun dp(v: Float) = (v * dens).toInt()
        val bande = LinearLayout(this)
        bande.orientation = LinearLayout.HORIZONTAL
        bande.gravity = Gravity.CENTER_VERTICAL
        bande.setPadding(dp(4f), dp(3f), dp(9f), dp(3f))
        bande.background = GradientDrawable().apply {
            cornerRadius = dp(20f).toFloat()
            setColor(0x9E0A0A0E.toInt())
            setStroke(dp(1f), 0x8CFFE27A.toInt())
        }
        val logo = android.widget.ImageView(this)
        try {
            assets.open("argent.webp").use { logo.setImageBitmap(android.graphics.BitmapFactory.decodeStream(it)) }
        } catch (_: Throwable) { }
        bande.addView(logo, LinearLayout.LayoutParams(dp(24f), dp(23f)))
        val t = TextView(this)
        t.setTextColor(0xFFFFE27A.toInt())
        t.textSize = 13f
        t.setTypeface(t.typeface, android.graphics.Typeface.BOLD)
        t.setPadding(dp(5f), 0, 0, 0)
        bande.addView(t, LinearLayout.LayoutParams(-2, -2))
        montantArgent = t
        val lp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END)
        lp.topMargin = dp(6f); lp.rightMargin = dp(8f)
        racine.addView(bande, lp)
        majArgent()
    }

    // ==================== Le téléphone de Rudy ====================
    private var boutonTelephone: TextView? = null

    /** En haut à gauche de la chambre : ouvre le téléphone, avec la chambre derrière. */
    private fun poseTelephone(racine: FrameLayout) {
        val dens = resources.displayMetrics.density
        fun dp(v: Float) = (v * dens).toInt()
        val b = TextView(this)
        b.text = "📱 Téléphone"
        b.setTextColor(0xFFFFEEC2.toInt())
        b.textSize = 13f
        b.setTypeface(b.typeface, android.graphics.Typeface.BOLD)
        b.setPadding(dp(12f), dp(7f), dp(12f), dp(7f))
        b.background = GradientDrawable().apply {
            cornerRadius = dp(20f).toFloat()
            setColor(0xD10C0818.toInt())
            setStroke(dp(1.5f), 0x80FFE1A0.toInt())
        }
        b.visibility = View.GONE                  // caché pendant l'ouverture du carton
        b.setOnClickListener { page("telephone.html?dec=room", "Chambre", garderMusique = true) }
        boutonTelephone = b
        val lp = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START)
        lp.topMargin = dp(6f); lp.leftMargin = dp(8f)
        racine.addView(b, lp)
    }

    /** Remet le montant a jour (au retour d'un jeu, d'une console ou de Shinato). */
    private fun majArgent() {
        montantArgent?.text = String.format(java.util.Locale.FRANCE, "%,d €", Argent.lire(this))
            .replace('\u00A0', ' ')
    }

    // ==================== YouTube sur la télé ====================
    private lateinit var racineChambre: FrameLayout
    private var teleWeb: android.webkit.WebView? = null      // la vidéo YouTube, posée sur l'écran de la télé
    private var youtubeAllume = false
    private var choixYoutube: FrameLayout? = null             // YouTube en plein écran, le temps de choisir
    private var webChoix: android.webkit.WebView? = null

    /** La télécommande : une vidéo du téléphone, ou YouTube. */
    private fun menuTelecommande() {
        val choix = if (teleAllumee) listOf("Mes vidéos", "YouTube", "Éteindre") else listOf("Mes vidéos", "YouTube")
        panneau("Que veux-tu regarder ?", choix, 1,
            0xF10A1435.toInt(), 0xFFFFC54E.toInt(), "RETOUR") { i ->
            when (i) {
                0 -> try {
                    choisirUneVideo.launch(arrayOf("video/*"))
                } catch (_: Throwable) {
                    dire("aucune application pour choisir une vidéo")
                }
                1 -> ouvrirYoutube()
                else -> eteindreLaTele()
            }
        }
    }

    /** L'identifiant d'une vidéo YouTube dans une adresse (watch, shorts, youtu.be), ou null. */
    private fun idYoutube(url: String?): String? {
        if (url == null) return null
        val m = Regex("(?:[?&]v=|/shorts/|youtu\\.be/|/embed/)([A-Za-z0-9_-]{11})").find(url) ?: return null
        return m.groupValues[1]
    }

    /** YouTube s'ouvre en grand : on choisit une vidéo, puis « Mettre sur la télé ». */
    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    private fun ouvrirYoutube() {
        if (choixYoutube != null) return
        val dens = resources.displayMetrics.density
        fun dp(v: Float) = (v * dens).toInt()
        val bloc = FrameLayout(this)
        bloc.setBackgroundColor(Color.BLACK)
        val web = android.webkit.WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = true
        bloc.addView(web, FrameLayout.LayoutParams(-1, -1))

        val barre = LinearLayout(this)
        barre.orientation = LinearLayout.HORIZONTAL
        barre.gravity = Gravity.CENTER
        barre.setPadding(dp(10f), dp(8f), dp(10f), dp(10f))
        barre.setBackgroundColor(0xE6101018.toInt())
        val fermer = Button(this)
        fermer.text = "✕ FERMER"
        fermer.setOnClickListener { fermerYoutube() }
        val mettre = Button(this)
        mettre.text = "▶ METTRE SUR LA TÉLÉ"
        mettre.setTextColor(0xFF2A1C06.toInt())
        mettre.background = GradientDrawable().apply { cornerRadius = dp(14f).toFloat(); setColor(0xFFFFC54E.toInt()) }
        mettre.visibility = android.view.View.GONE
        barre.addView(fermer)
        barre.addView(mettre, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(12f) })
        bloc.addView(barre, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        var videoChoisie: String? = null
        fun suivre(url: String?) {
            videoChoisie = idYoutube(url)
            mettre.visibility = if (videoChoisie != null) android.view.View.VISIBLE else android.view.View.GONE
        }
        web.webViewClient = object : android.webkit.WebViewClient() {
            override fun doUpdateVisitedHistory(v: android.webkit.WebView, url: String?, isReload: Boolean) {
                super.doUpdateVisitedHistory(v, url, isReload)
                suivre(url)                              // YouTube change d'adresse sans recharger la page
            }
            override fun onPageFinished(v: android.webkit.WebView, url: String?) {
                super.onPageFinished(v, url)
                suivre(url)
            }
        }
        web.webChromeClient = android.webkit.WebChromeClient()
        mettre.setOnClickListener {
            val id = videoChoisie
            if (id != null) {
                fermerYoutube()
                jouerYoutubeSurLaTele(id)
            }
        }
        racineChambre.addView(bloc, FrameLayout.LayoutParams(-1, -1))
        choixYoutube = bloc
        webChoix = web
        son.enPause(true)                                // la radio se tait pendant qu'on cherche
        web.loadUrl("https://m.youtube.com/")
    }

    private fun fermerYoutube() {
        val bloc = choixYoutube ?: return
        choixYoutube = null
        val w = webChoix
        webChoix = null
        try { w?.stopLoading(); w?.loadUrl("about:blank"); w?.destroy() } catch (_: Throwable) { }
        racineChambre.removeView(bloc)
        if (!teleAllumee) son.enPause(false)
    }

    /** La vidéo choisie se joue dans l'écran de la télé. */
    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    private fun jouerYoutubeSurLaTele(id: String) {
        try { lecteur?.stop() } catch (_: Throwable) {}
        try { lecteur?.release() } catch (_: Throwable) {}
        lecteur = null
        ecranTele.alpha = 0f
        var w = teleWeb
        if (w == null) {
            w = android.webkit.WebView(this)
            w.resumeTimers()
            w.setBackgroundColor(Color.BLACK)
            // si YouTube fait planter l'affichage : la télé s'éteint au lieu de tout bloquer
            w.webViewClient = object : android.webkit.WebViewClient() {
                override fun onRenderProcessGone(v: android.webkit.WebView, d: android.webkit.RenderProcessGoneDetail): Boolean {
                    try { racineChambre.removeView(v); v.destroy() } catch (_: Throwable) { }
                    if (teleWeb === v) teleWeb = null
                    youtubeAllume = false
                    return true
                }
            }
            w.settings.javaScriptEnabled = true
            w.settings.domStorageEnabled = true
            w.settings.mediaPlaybackRequiresUserGesture = false   // elle démarre toute seule
            w.webChromeClient = android.webkit.WebChromeClient()
            w.isVerticalScrollBarEnabled = false
            w.isHorizontalScrollBarEnabled = false
            racineChambre.addView(w, racineChambre.indexOfChild(ecranTele) + 1, FrameLayout.LayoutParams(1, 1))
            teleWeb = w
        }
        val page = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
            "<style>html,body{margin:0;height:100%;background:#000;overflow:hidden}" +
            "iframe{position:fixed;left:0;top:0;width:100%;height:100%;border:0}</style></head><body>" +
            "<iframe src='https://www.youtube-nocookie.com/embed/" + id +
            "?autoplay=1&playsinline=1&rel=0&modestbranding=1&origin=https://www.youtube-nocookie.com' " +
            "allow='autoplay; encrypted-media; picture-in-picture; fullscreen' allowfullscreen " +
            "referrerpolicy='strict-origin-when-cross-origin'></iframe></body></html>"
        w.loadDataWithBaseURL("https://www.youtube-nocookie.com/", page, "text/html", "utf-8", null)
        youtubeAllume = true
        teleAllumee = true
        placerEcranTele(vue.rectangleTele())
        son.enPause(true)                                // la radio se tait pendant la vidéo
        dire("YouTube sur la télé")
    }

    /** YouTube s'arrête (télé éteinte, console posée, autre vidéo). */
    private fun couperYoutube() {
        if (!youtubeAllume) return
        youtubeAllume = false
        val w = teleWeb
        try { w?.loadUrl("about:blank") } catch (_: Throwable) { }
        w?.visibility = android.view.View.INVISIBLE
    }

    /** Le retour Android : dans YouTube, on revient en arrière, puis on ferme. */
    @Deprecated("Retour Android")
    override fun onBackPressed() {
        if (calque != null && choixYoutube == null) {
            calque?.evaluateJavascript("window.retourDemande&&window.retourDemande()", null)
            return
        }
        val w = webChoix
        if (choixYoutube != null) {
            if (w != null && w.canGoBack()) w.goBack() else fermerYoutube()
            return
        }
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }

    private var teleAllumee = false
    /** La video de la prochaine console, deja prete a partir. */
    private var lecteurPret: android.media.MediaPlayer? = null
    private var videoPrete: String? = null

    /** Prepare a l'avance la sequence de la console suivante, pour qu'elle parte net. */
    /**
     * Preparer une video d'avance, sur un fil a part.
     *
     * La preparation lit le fichier et decode ses premieres images : faite sur
     * le fil de l'affichage, elle figeait la chambre le temps d'un battement.
     * Elle se fait donc a cote, et la video est prete avant meme l'appui.
     */
    private fun preparerVideo(console: Decor.ConsolePosee) {
        if (videoPrete == console.video || videoEnPreparation == console.video) return
        videoEnPreparation = console.video
        Thread {
            var pret: android.media.MediaPlayer? = null
            try {
                val d = assets.openFd("chambre/" + console.video)
                pret = android.media.MediaPlayer().apply {
                    setDataSource(d.fileDescriptor, d.startOffset, d.length)
                    setVolume(0.85f, 0.85f)
                    prepare()
                }
                d.close()
            } catch (_: Throwable) {
                try { pret?.release() } catch (_: Throwable) {}
                pret = null
            }
            runOnUiThread {
                videoEnPreparation = null
                if (pret == null) return@runOnUiThread
                try { lecteurPret?.release() } catch (_: Throwable) {}
                lecteurPret = pret
                videoPrete = console.video
            }
        }.apply { priority = Thread.MIN_PRIORITY }.start()
    }

    private var videoEnPreparation: String? = null
    private var essaisVideo = 0

    /*
     * La surface de l'ecran de la tele.
     *
     * Avant, chaque video en fabriquait une nouvelle sans jamais rendre
     * l'ancienne : au fil des consoles sorties du carton, la memoire des
     * images se remplissait, jusqu'aux ralentissements et a l'ecran noir.
     * Il n'y en a plus qu'une, rendue a la fermeture.
     */
    private var surfaceTele: android.view.Surface? = null
    private var textureTele: android.graphics.SurfaceTexture? = null

    private fun surfaceDeLaTele(st: android.graphics.SurfaceTexture): android.view.Surface {
        val s = surfaceTele
        if (s != null && textureTele === st && s.isValid) return s
        try { s?.release() } catch (_: Throwable) {}
        return android.view.Surface(st).also { surfaceTele = it; textureTele = st }
    }

    /** La tele s'allume et joue la sequence de demarrage de cette console. */
    /** La tele s'eteint : la video s'arrete et l'ecran s'efface en douceur. */
    private fun eteindreLaTele() {
        couperYoutube()
        teleAllumee = false
        try { lecteur?.stop() } catch (_: Throwable) {}
        try { lecteur?.release() } catch (_: Throwable) {}
        lecteur = null
        ecranTele.animate().alpha(0f).setDuration(500).start()
        son.enPause(false)          // la radio reprend
    }

    private fun allumerLaTele(console: Decor.ConsolePosee) {
        couperYoutube()                             // la console reprend la télé
        teleAllumee = true
        ecranTele.alpha = 1f
        placerEcranTele(vue.rectangleTele())

        try { lecteur?.release() } catch (_: Throwable) {}
        lecteur = null

        val surface = ecranTele.surfaceTexture ?: return
        try {
            // si elle a ete preparee d'avance, elle part a l'instant meme
            val pret = if (videoPrete == console.video) lecteurPret else null
            lecteurPret = null; videoPrete = null
            if (pret == null) {
                // pas encore prete : on la prepare a cote et on rappelle
                // cette meme fonction des qu'elle l'est.
                // Au bout de 5 secondes on abandonne : avant, si la video ne
                // voulait pas se preparer, l'appli relancait l'essai toutes
                // les 120 ms sans jamais s'arreter, et tout ralentissait.
                if (essaisVideo++ >= 40) {
                    essaisVideo = 0
                    teleAllumee = false
                    ecranTele.alpha = 0f
                    return
                }
                preparerVideo(console)
                vue.postDelayed({ if (teleAllumee) allumerLaTele(console) }, 120)
                teleAllumee = true
                return
            }
            essaisVideo = 0
            lecteur = pret.apply {
                setSurface(surfaceDeLaTele(surface))
                setOnCompletionListener {
                    teleAllumee = false
                    ecranTele.animate().alpha(0f).setDuration(600).start()
                }
                start()
            }
            son.enPause(true)                       // la radio se tait pendant la sequence
            ecranTele.postDelayed({ son.enPause(false) }, 6000)
        } catch (_: Throwable) { teleAllumee = false; ecranTele.alpha = 0f }
    }

    /**
     * Ce que l'APK contient reellement : les moteurs presents, et les
     * emulateurs assembles depuis leur propre projet. Le bilan est ecrit a la
     * compilation, donc il ne ment pas.
     */
    private fun montrerAssemblage() {
        val texte = try {
            assets.open("chambre/assemblage.txt").bufferedReader().use { it.readText() }
        } catch (_: Throwable) { "aucun bilan : cet APK date d'avant cette mesure." }
        val plantage = try {
            val f = java.io.File(filesDir, "dernier_plantage.txt")
            if (f.exists()) "\n\nDernier plantage :\n" + f.readText() else ""
        } catch (_: Throwable) { "" }

        /*
         * Ce qu'a fait la console posee sur la table.
         *
         * Un arret dans le coeur natif ne remonte pas jusqu'a Java : aucun
         * plantage n'est alors enregistre, et l'ecran se ferme sans rien dire.
         * Le journal, lui, garde la trace de chaque etape franchie. On y
         * cherche la derniere fois que CETTE console est partie, et on montre
         * tout ce qui a suivi : c'est son compte rendu a elle.
         */
        /*
         * Ce qu'Android a note pour notre propre application.
         *
         * Mupen64Plus tourne dans le meme processus que la Chambre : ses
         * erreurs sont donc dans le journal d'Android, sous notre numero. Une
         * application a le droit de lire le sien. C'est le seul moyen de voir
         * pourquoi un ecran se referme sans rien dire — ni plantage Java, ni
         * message a l'ecran.
         */
        val androidJournal = try {
            val p = Runtime.getRuntime().exec(
                arrayOf("logcat", "-d", "-t", "400", "--pid=" + android.os.Process.myPid()))
            val lignes = p.inputStream.bufferedReader().readLines()
            /*
             * Ce qui nous interesse vraiment : ce que dit SON emulateur.
             *
             * Je gardais aussi tous les avertissements du systeme, et ils
             * noyaient ses propres messages — c'est pour cela qu'on ne voyait
             * jamais la raison du refus. On prend d'abord les siens.
             */
            val siennes = lignes.filter { l ->
                l.contains("mupen", true) || l.contains("paulscode", true) ||
                l.contains("CoreService", true) || l.contains("CoreFragment", true) ||
                l.contains("GameActivity", true) || l.contains("dolphin", true) ||
                l.contains("citra", true) || l.contains("AndroidRuntime")
            }
            val utiles = if (siennes.isNotEmpty()) siennes
                         else lignes.filter { it.contains(" E ") }
            if (utiles.isEmpty()) ""
            else "\n\nCe qu'Android a note :\n" +
                 utiles.takeLast(16).joinToString("\n") { it.take(150) }
        } catch (_: Throwable) { "" }

        val posee = vue.consolePosee()
        val journal = try {
            val f = java.io.File(java.io.File(filesDir, "systeme"), "journal_appli.txt")
            if (!f.exists()) "\n\n(aucune console n'a encore laissé de trace)"
            else {
                val lignes = f.readLines()
                if (posee == null) {
                    // aucune console sur la table : on montre quand meme les
                    // dernieres traces, c'est souvent la que se cache la panne
                    val suite = lignes.filter { it.isNotBlank() }.takeLast(22)
                    if (suite.isEmpty()) "\n\n(rien n'a encore ete tente)"
                    else "\n\nDernieres traces :\n" + suite.joinToString("\n")
                } else {
                    val marque = "=== CONSOLE " + posee.nom + " "
                    val depart = lignes.indexOfLast { it.startsWith(marque) }
                    if (depart < 0) {
                        "\n\n" + posee.nom + " : aucun lancement enregistré."
                    } else {
                        val suite = lignes.drop(depart)
                            .filter { it.isNotBlank() }
                            .takeLast(22)
                        "\n\nCompte rendu de " + posee.nom + " :\n" + suite.joinToString("\n") +
                        "\n\n(si ça s'arrête après « avant ouverture du cœur », c'est le" +
                        " moteur qui refuse ; après « ROM reçue », c'est le jeu.)"
                    }
                }
            }
        } catch (_: Throwable) { "" }

        menu().setTitle(if (posee != null) posee.nom + " — compte rendu" else "Ce que contient cet APK")
            .setMessage(texte + plantage + journal + androidJournal)
            .setPositiveButton("Fermer", null)
            .setNegativeButton("Tout effacer") { _, _ ->
                try { java.io.File(filesDir, "dernier_plantage.txt").delete() } catch (_: Throwable) {}
                try { java.io.File(java.io.File(filesDir, "systeme"), "journal_appli.txt").delete() } catch (_: Throwable) {}
            }
            .setNeutralButton("Copier") { _, _ ->
                try {
                    val cb = getSystemService(android.content.ClipboardManager::class.java)
                    cb.setPrimaryClip(android.content.ClipData.newPlainText(
                        "bilan", texte + plantage + journal + androidJournal))
                    dire("copié")
                } catch (_: Throwable) {}
            }
            .show()
    }

    // ================= les menus =================

    private fun proposerTiroir() {
        panneau("Que veux-tu faire ?", listOf("Dessiner", "Jouer aux cartes"), 0,
            0xF10A1435.toInt(), 0xFFFFC54E.toInt(), "NON, REFERMER") { i ->
            if (i == 0) confirmer("Voulez-vous dessiner ?") {
                startActivity(Intent(this, com.rudy.chambre.atelier.AtelierActivity::class.java))
            } else menuCartes()
        }
    }

    private fun menuCartes() {
        panneau("À quel jeu de cartes veux-tu jouer ?", listOf("Poker", "Blackjack"), 0,
            0xF10A1435.toInt(), 0xFFFFC54E.toInt(), "RETOUR") { i ->
            startActivity(Intent(this, if (i == 0)
                com.rudy.chambre.cartes.PokerActivity::class.java
            else com.rudy.chambre.cartes.BlackjackActivity::class.java))
        }
    }

    /**
     * L'armoire de gauche, comme dans sa page : un panneau en bas au centre,
     * a neuf pour cent du bord, violet borde d'or, avec ses trois jeux cote a
     * cote et le bouton pour refermer.
     */
    private fun menuJeuxDeSociete() {
        panneau("À quoi veux-tu jouer ?",
                listOf("Monopoly", "Échecs", "Dames"),
                1,                                  // les echecs sont mis en avant
                0xF5261A42.toInt(), 0x59FFDC96,
                "← Refermer l'armoire") { i ->
            when (i) {
                0 -> confirmer("Voulez-vous jouer au Monopoly ?") { startActivity(Intent(this, com.rudy.chambre.monopoly.MonopolyActivity::class.java)) }
                1 -> confirmer("Voulez-vous jouer aux échecs ?") { startActivity(Intent(this, com.rudy.chambre.echecs.EchecsActivity::class.java)) }
                2 -> confirmer("Voulez-vous jouer aux dames ?") { startActivity(Intent(this, com.rudy.chambre.dames.DamesActivity::class.java)) }
            }
        }
    }

    private var panneauOuvert: View? = null

    /**
     * Un panneau de choix, pose en bas de l'ecran comme les siens.
     * [enAvant] designe le bouton mis en valeur, [fermer] le texte du retour.
     */
    private fun panneau(titre: String, choix: List<String>, enAvant: Int,
                        fond: Int, bordure: Int, fermer: String,
                        surChoix: (Int) -> Unit) {
        panneauOuvert?.let { (it.parent as? FrameLayout)?.removeView(it) }

        val dens = resources.displayMetrics.density
        fun dp(v: Float) = (v * dens).toInt()

        val bloc = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12f), dp(10f), dp(12f), dp(10f))
            background = GradientDrawable().apply {
                cornerRadius = dp(28f).toFloat()
                colors = intArrayOf(0xFC071331.toInt(), fond, 0xFC071331.toInt())
                orientation = GradientDrawable.Orientation.TL_BR
                setStroke(dp(3f), bordure)
            }
        }
        bloc.addView(TextView(this).apply {
            text = "▲  $titre  ▲"; textSize = 16f
            setTextColor(0xFFFFEEC2.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(10f))
        })

        val rangee = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        choix.forEachIndexed { i, nom ->
            rangee.addView(Button(this).apply {
                text = nom; textSize = 11f
                setTextColor(if (i == enAvant) 0xFF2A1C06.toInt() else Color.WHITE)
                background = GradientDrawable().apply {
                cornerRadius = dp(18f).toFloat()
                setColor(if (i == enAvant) 0xFF45208D.toInt() else 0xFF0E1B42.toInt())
                setStroke(dp(2f), if (i == enAvant) 0xFFFFD35A.toInt() else 0xFFB67A21.toInt())
                }
                setOnClickListener { fermerLePanneau(); surChoix(i) }
            }, LinearLayout.LayoutParams(0, -2, 1f).apply {
                if (i > 0) leftMargin = dp(8f)
            })
        }
        bloc.addView(rangee)

        bloc.addView(Button(this).apply {
            text = fermer; textSize = 12f
            setTextColor(0xFFCFC7B7.toInt())
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { fermerLePanneau(); if (vue.porteG > 0.5f) fermerPortes() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6f) })

        val place = FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        place.bottomMargin = (resources.displayMetrics.heightPixels * .03f).toInt()
        place.width = (resources.displayMetrics.widthPixels * .74f).toInt()
        (findViewById<FrameLayout>(android.R.id.content).getChildAt(0) as FrameLayout)
            .addView(bloc, place)
        panneauOuvert = bloc
        bloc.alpha = 0f
        bloc.translationY = dp(14f).toFloat()
        bloc.animate().alpha(1f).translationY(0f).setDuration(220).start()
    }

    private fun fermerLePanneau() {
        val p = panneauOuvert ?: return
        panneauOuvert = null
        p.animate().alpha(0f).translationY(20f).setDuration(180)
            .withEndAction { (p.parent as? FrameLayout)?.removeView(p) }.start()
    }

    /** Le même cadre Zelda pour toutes les confirmations Oui / Non. */
    private fun confirmer(question: String, oui: () -> Unit) {
        panneau(question, listOf("OUI", "NON"), 0,
            0xF10A1435.toInt(), 0xFFFFC54E.toInt(), "RETOUR") { i ->
            if (i == 0) oui()
        }
    }

    /** La baie vitrée : on sort à Shinato (les jeux de plein air sont maintenant dans la rue). */
    private fun menuDehors() {
        confirmer("Voulez-vous sortir à Shinato ?") {
            startActivity(Intent(this, ShinatoActivity::class.java))
        }
    }

    /** La vitrine de la console posee sur le bureau. */
    private fun ouvrirVitrine() {
        val console = vue.consolePosee()
        if (console == null) {
            dire("sors d'abord une console du carton")
            fermerPortes()
            return
        }
        val fichiers = mapOf(
            "nes" to "nes", "gb" to "gameboy", "snes" to "snes", "md" to "megadrive",
            "gba" to "gba", "ds" to "ds", "ps1" to "ps1", "n64" to "n64", "dc" to "dreamcast",
            "psp" to "psp", "gc" to "gamecube", "wii" to "wii", "3ds" to "3ds"
        )
        val f = fichiers[console.id] ?: return
        page("jeux/vitrine-$f.html", "Vitrine " + console.nom)
    }

    private fun fermerPortes() {
        if (vue.porteG > 0.5f) { son.bruit("porte_ferme.mp3"); vue.bougerPorte(true, false) }
        if (vue.porteD > 0.5f) { son.bruit("porte_ferme.mp3"); vue.bougerPorte(false, false) }
    }

    /** Ouvre une page par-dessus la chambre, et coupe la musique le temps du jeu
     *  (sauf pour le téléphone : la musique de la chambre reste en fond). */
    private fun page(chemin: String, titre: String, paysage: Boolean = false, garderMusique: Boolean = false) {
        if (!garderMusique) son.enPause(true)
        startActivity(Intent(this, PageActivity::class.java)
            .putExtra("page", chemin)
            .putExtra("titre", titre)
            .putExtra("paysage", paysage))
    }

    // ==================== La visite d'une fille ====================
    /*
     * La fille est un calque transparent posé sur la vraie chambre : la chambre
     * reste entière (bureau, consoles, tiroirs, télé, livres…). Seuls ses
     * propres morceaux (elle, son menu, ses discussions, la balade) prennent
     * le doigt ; le reste passe à la chambre en dessous.
     */
    private var calque: CalqueVisite? = null
    private var derniereCamera = ""

    private fun verifierVisite() {
        val demandee = Visite.prendreDemande(this)
        if (demandee.isNotEmpty()) {
            if (calque == null) ouvrirVisite(demandee)
            else calque?.evaluateJavascript("window.nouvelleVisite&&window.nouvelleVisite('$demandee')", null)
        } else if (calque == null) {
            val ici = Visite.ici(this)
            if (ici.isNotEmpty()) ouvrirVisite(ici)          // la chambre a été recréée : elle est toujours là
        }
        calque?.evaluateJavascript("window.enPause&&window.enPause(false)", null)
    }

    private fun ouvrirVisite(id: String) {
        if (!::racineChambre.isInitialized) return
        val racine = racineChambre
        Visite.arrivee(this, id)
        boutonTelephone?.visibility = View.VISIBLE
        val serveur = androidx.webkit.WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", androidx.webkit.WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        val w = CalqueVisite(this).apply {
            resumeTimers()
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            overScrollMode = View.OVER_SCROLL_NEVER
            webViewClient = object : android.webkit.WebViewClient() {
                override fun shouldInterceptRequest(v: android.webkit.WebView,
                                                    r: android.webkit.WebResourceRequest): android.webkit.WebResourceResponse? =
                    serveur.shouldInterceptRequest(r.url)
                override fun onPageFinished(v: android.webkit.WebView?, url: String?) {
                    derniereCamera = ""
                    vue.invalidate()                          // la page reçoit tout de suite où sont les murs
                }
                // la page de la fille a été arrêtée par Android : on la remet, elle est toujours là
                override fun onRenderProcessGone(v: android.webkit.WebView, d: android.webkit.RenderProcessGoneDetail): Boolean {
                    try { racineChambre.removeView(v); v.destroy() } catch (_: Throwable) { }
                    if (calque === v) calque = null
                    val ici = Visite.ici(this@ChambreActivity)
                    if (ici.isNotEmpty()) vue.postDelayed({ if (calque == null) ouvrirVisite(ici) }, 600)
                    return true
                }
            }
            webChromeClient = android.webkit.WebChromeClient()
            addJavascriptInterface(PontVisite(), "Android")
            loadUrl("https://appassets.androidplatform.net/assets/web/visite.html?fille=" + id.filter { it.isLetter() })
        }
        // au-dessus de la chambre, sous le téléphone et le porte-monnaie
        val i = racine.indexOfChild(etiquette) + 1
        racine.addView(w, i, FrameLayout.LayoutParams(-1, -1))
        calque = w
        derniereCamera = ""
    }

    private fun fermerVisite() {
        val w = calque ?: return
        calque = null
        Visite.partie(this)
        try { racineChambre.removeView(w); w.destroy() } catch (_: Throwable) { }
        try { SonPartage.volume(1f) } catch (_: Throwable) { }
    }

    /** À chaque image de la chambre : le calque apprend où est le mur (en pixels de la page). */
    private fun cameraVisite(m: Int, l: Float, t: Float, w: Float, h: Float) {
        val c = calque ?: return
        val d = resources.displayMetrics.density
        val txt = String.format(java.util.Locale.US, "%d,%.1f,%.1f,%.1f,%.1f", m, l / d, t / d, w / d, h / d)
        if (txt == derniereCamera) return
        derniereCamera = txt
        c.evaluateJavascript("window.camera&&window.camera($txt)", null)
    }

    private inner class PontVisite {
        @android.webkit.JavascriptInterface
        fun zones(json: String) { calque?.majZones(json, resources.displayMetrics.density) }

        @android.webkit.JavascriptInterface
        fun regarder(mur: Int, fx: Float) { runOnUiThread { vue.regarder(mur, fx) } }

        @android.webkit.JavascriptInterface
        fun finVisite() { runOnUiThread { fermerVisite() } }

        @android.webkit.JavascriptInterface
        fun retourChambre() { runOnUiThread { fermerVisite() } }

        @android.webkit.JavascriptInterface
        fun argent(): Int = Argent.lire(this@ChambreActivity)

        @android.webkit.JavascriptInterface
        fun ajouterArgent(n: Int) { Argent.ajouter(this@ChambreActivity, n); runOnUiThread { majArgent() } }

        @android.webkit.JavascriptInterface
        fun radio(allumee: Boolean) {
            runOnUiThread {
                // pendant une vidéo ou une balade : la radio s'arrête vraiment, puis reprend
                SonPartage.volume(if (allumee) 1f else 0f)
                try { if (allumee) { if (!teleAllumee && !youtubeAllume) son.enPause(false) } else son.enPause(true) } catch (_: Throwable) { }
            }
        }
    }

    override fun onResume() {
        majArgent()                              // l'argent peut avoir change dans un jeu ou a Shinato
        // les minuteries des pages web sont communes à toute l'appli : on les relance toujours
        try { (calque ?: teleWeb ?: webChoix)?.resumeTimers() } catch (_: Throwable) { }
        try { calque?.onResume() } catch (_: Throwable) { }
        try { verifierVisite() } catch (_: Throwable) { }
        try { teleWeb?.onResume(); webChoix?.onResume() } catch (_: Throwable) { }
        super.onResume()
        // si une console vient de partir, la chambre ne fait que passer :
        // sa musique reste muette, celle du jeu prend le relais
        if (!SonPartage.consoleVientDePartir()) {
            SonPartage.volume(1f)          // rendu apres le passage d'un emulateur
            son.enPause(false)
        }
    }

    override fun onPause() {
        try { teleWeb?.onPause(); webChoix?.onPause() } catch (_: Throwable) { }
        try { calque?.evaluateJavascript("window.enPause&&window.enPause(true)", null) } catch (_: Throwable) { }
        super.onPause()
        // On ouvre un jeu ou une vitrine : la chambre passe derriere, mais
        // elle reste a l'ecran de l'application. La radio continue donc de
        // jouer, comme quand on change de piece.
        if (isFinishing) son.enPause(true)
    }

    /**
     * L'application passe vraiment en arriere-plan (bouton accueil, autre
     * application) : la, on met la radio en pause.
     */
    override fun onStop() {
        super.onStop()
        val enAvant = (application as? Chambre)?.enAvantPlan ?: false
        if (!enAvant) son.enPause(true)
    }

    override fun onDestroy() {
        try { teleWeb?.destroy(); webChoix?.destroy(); calque?.destroy() } catch (_: Throwable) { }
        try { lecteur?.release() } catch (_: Throwable) {}
        try { lecteurPret?.release() } catch (_: Throwable) {}
        try { surfaceTele?.release() } catch (_: Throwable) {}
        surfaceTele = null; textureTele = null
        son.liberer()
        super.onDestroy()
    }
}

/**
 * « Sortir à Shinato » : le jeu Rudy Style (la rue, la plage, la moto, le Pixel Bar,
 * le Dragon d'Or, la ville délabrée, Vaviel et leurs mini-jeux), dans une WebView.
 * Rangée ici, dans le même fichier que la chambre, pour être toujours compilée avec elle.
 *
 * Chaque lieu et chaque mini-jeu est un fichier à part dans assets/shinato :
 *   index.html   la rue de Shinato (point de départ)
 *   lieux/       les autres cartes, chargées seulement quand on y va
 *   jeux/        les mini-jeux, chargés seulement quand on les lance
 */
class ShinatoActivity : androidx.activity.ComponentActivity() {
    private lateinit var web: android.webkit.WebView
    private var vueDetruite = false          // l'affichage a été arrêté par Android (voir onRenderProcessGone)

    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        pleinEcran()

        val serveur = androidx.webkit.WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", androidx.webkit.WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = android.webkit.WebView(this)
        web.setBackgroundColor(android.graphics.Color.BLACK)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false      // la musique de la ville démarre sans attendre
        web.settings.setSupportZoom(false)
        web.settings.builtInZoomControls = false
        // Pas de couche a part pour la WebView : elle obligeait a redessiner
        // toute la rue une seconde fois a chaque image (ralentissements) et
        // pouvait laisser l'ecran noir sur les grandes pages.
        web.overScrollMode = android.view.View.OVER_SCROLL_NEVER
        web.isLongClickable = false
        web.setOnLongClickListener { true }                          // pas de menu d'appui long
        // Après le retour d'un mini-jeu Android, certains téléphones gardent
        // le focus tactile sur l'activité qui vient de se fermer. La rue doit
        // redevenir immédiatement la cible des doigts.
        web.isFocusable = true
        web.isFocusableInTouchMode = true
        web.webViewClient = object : android.webkit.WebViewClient() {
            override fun shouldInterceptRequest(
                v: android.webkit.WebView,
                r: android.webkit.WebResourceRequest
            ): android.webkit.WebResourceResponse? = serveur.shouldInterceptRequest(r.url)

            // Si l'affichage de Shinato manque de mémoire, Android l'arrête. Sans ceci, l'écran
            // se fige ou l'appli se ferme : on relance Shinato proprement à la place.
            override fun onRenderProcessGone(
                v: android.webkit.WebView,
                d: android.webkit.RenderProcessGoneDetail
            ): Boolean {
                try { (v.parent as? android.view.ViewGroup)?.removeView(v) } catch (_: Throwable) { }
                try { v.destroy() } catch (_: Throwable) { }
                vueDetruite = true
                runOnUiThread { recreate() }
                return true
            }
        }
        web.webChromeClient = android.webkit.WebChromeClient()
        // Les terrains de la rue (flèche jaune + JOUER) lancent les jeux de l'appli.
        // Quand le jeu se termine, on revient ici, dans la rue.
        web.addJavascriptInterface(object {
            @android.webkit.JavascriptInterface
            fun jouer(nom: String) {
                val ecran: Class<*>? = when (nom) {
                    "penalty" -> com.rudy.chambre.penalty.PenaltyActivity::class.java
                    "paniers" -> com.rudy.chambre.basket.BasketActivity::class.java
                    "balle" -> com.rudy.chambre.balle.PartieActivity::class.java
                    "pariboxe" -> com.rudy.chambre.pariboxe.PariBoxeActivity::class.java
                    else -> null
                }
                if (ecran != null) runOnUiThread {
                    startActivity(android.content.Intent(this@ShinatoActivity, ecran).putExtra("depuis_shinato", true))
                }
            }

            /** L'argent de Rudy, affiche en haut a droite des rues. */
            @android.webkit.JavascriptInterface
            fun argent(): Int = Argent.lire(this@ShinatoActivity)

            /** Gagner ou depenser (pour plus tard : gains des jeux, achats). */
            @android.webkit.JavascriptInterface
            fun ajouterArgent(n: Int) { Argent.ajouter(this@ShinatoActivity, n) }

            /** Le téléphone : une fille a dit « oui ». Rudy rentre chez lui, elle arrive. */
            @android.webkit.JavascriptInterface
            fun visite(id: String) {
                runOnUiThread {
                    Visite.demander(this@ShinatoActivity, id)
                    try {
                        startActivity(android.content.Intent(this@ShinatoActivity, ChambreActivity::class.java)
                            .addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP or
                                      android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP))
                    } catch (_: Throwable) {}
                    finish()
                }
            }

            /** Tout à gauche de la rue : « Voulez-vous rentrer ? » -> OUI : retour au bureau. */
            @android.webkit.JavascriptInterface
            fun rentrer() {
                runOnUiThread { finish() }
            }
        }, "Chambre")

        val cadre = android.widget.FrameLayout(this)
        cadre.setBackgroundColor(android.graphics.Color.BLACK)
        cadre.addView(web, android.widget.FrameLayout.LayoutParams(-1, -1))
        setContentView(cadre)

        // la musique de la chambre laisse la place à celle de Shinato
        SonPartage.dansShinato = true
        try { SonPartage.volume(0f) } catch (_: Throwable) { }
        web.loadUrl("https://appassets.androidplatform.net/assets/shinato/index.html")
    }

    private fun pleinEcran() {
        val c = androidx.core.view.WindowInsetsControllerCompat(window, window.decorView)
        c.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        c.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            pleinEcran()
            if (!vueDetruite) web.post { web.requestFocus() }
        }
    }

    override fun onResume() {
        super.onResume()
        if (!vueDetruite) {
            web.onResume(); web.resumeTimers()
            web.evaluateJavascript("try{window.repriseApresPause&&window.repriseApresPause()}catch(e){}", null)
            web.post { web.requestFocus() }
        }
        // au retour d'un jeu, la musique de la chambre reste coupée : c'est celle de Shinato qui joue
        try { SonPartage.volume(0f) } catch (_: Throwable) { }
    }

    override fun onPause() {
        // Plus de son quand l'appli passe derrière. Surtout PAS pauseTimers() : il gèle les pages
        // web de TOUTE l'appli (le téléphone de la chambre restait noir après un passage en ville).
        if (!vueDetruite) {
            web.evaluateJavascript("try{window.pauseAvantSortie&&window.pauseAvantSortie()}catch(e){}", null)
            web.onPause()
        }
        super.onPause()
    }

    @Deprecated("Le retour Android revient dans la chambre.")
    override fun onBackPressed() {
        finish()
    }

    override fun onDestroy() {
        if (!vueDetruite) try { web.resumeTimers(); web.stopLoading(); web.loadUrl("about:blank"); web.destroy() } catch (_: Throwable) { }
        SonPartage.dansShinato = false
        try { Ambiance.rendreLaMusique() } catch (_: Throwable) { }
        super.onDestroy()
    }
}

/**
 * L'argent de Rudy. Une seule valeur, gardée dans le téléphone, partagée par la chambre
 * et par les rues de Shinato (la page web le lit par le pont « Chambre »).
 */
object Argent {
    private const val FICHIER = "rudy_argent"
    private const val CLE = "argent"
    fun lire(ctx: android.content.Context): Int =
        ctx.getSharedPreferences(FICHIER, android.content.Context.MODE_PRIVATE).getInt(CLE, 1000)          // on commence le jeu avec 1000 €
    fun ecrire(ctx: android.content.Context, n: Int) {
        ctx.getSharedPreferences(FICHIER, android.content.Context.MODE_PRIVATE)
            .edit().putInt(CLE, maxOf(0, n)).apply()
    }
    fun ajouter(ctx: android.content.Context, n: Int) = ecrire(ctx, lire(ctx) + n)
}
