package com.rudy.chambre.balle

import android.app.AlertDialog
import android.content.pm.ActivityInfo
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.hypot

/**
 * La balle au prisonnier de Rudy, en natif.
 *
 * L'affiche, puis le match ; son manche a balai a gauche et ses quatre
 * boutons a droite, comme dans sa page.
 */
class PartieActivity : ComponentActivity() {

    private lateinit var vue: VuePartie
    private lateinit var racine: FrameLayout
    private var son: SonBalle? = null
    private var commandes: Commandes? = null

    override fun onCreate(etat: Bundle?) {
        super.onCreate(etat)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        son = SonBalle()
        vue = VuePartie(this)
        vue.partie.surSon = { quoi, force -> son?.jouer(quoi, force) }
        vue.partie.surTexteTir = { t -> commandes?.texteTir = t }
        vue.surFin = { titre -> finDePartie(titre) }

        racine = FrameLayout(this)
        racine.setBackgroundColor(Color.BLACK)
        racine.addView(vue, FrameLayout.LayoutParams(-1, -1))
        commandes = Commandes(this, vue.partie).apply {
            surEsquive = {
                val me = vue.partie.me()
                if (me.dodge <= 0f && me.cool <= 0f) { me.dodge = .38f; son?.jouer("esquive", 1f) }
            }
            surAttraper = {
                val me = vue.partie.me()
                if (vue.partie.B.held !== me && !me.pendingJail && me.fallA <= 0f) {
                    // sa fenetre de rattrapage : un tiers de seconde
                    me.catchTry = .32f
                    son?.jouer("esquive", .7f)
                }
            }
            surPasse = {
                val partie = vue.partie
                val me = partie.me()
                if (partie.B.held === me) partie.passBall(me)
                else partie.dire("TU N'AS PAS LA BALLE")
            }
            surTirDebut = { vue.partie.charging = true; vue.partie.shotCharge = 0f }
            surTirFin = {
                val partie = vue.partie
                val me = partie.me()
                val cible = partie.ciblesDe(me).minByOrNull {
                    hypot(it.x - me.x, it.y - me.y)
                }
                if (partie.B.held === me) {
                    // s'il est encore en repos, le tir attend son tour
                    if (me.cool > 0f) {
                        partie.tirEnAttente = true
                        partie.chargeEnAttente = partie.shotCharge
                    } else {
                        partie.launch(me, cible, partie.shotCharge)
                    }
                }
                partie.charging = false; partie.shotCharge = 0f
            }
        }
        racine.addView(commandes, FrameLayout.LayoutParams(-1, -1))
        racine.addView(retour())
        setContentView(racine)
        com.rudy.chambre.Ambiance.musiqueDuJeu(this, "balle/musique_balle.webm", 0.85f)

        afficherAffiche()
    }

    /** L'affiche du match, avant le coup d'envoi. */
    private fun afficherAffiche() {
        val bloc = FrameLayout(this)
        bloc.setBackgroundColor(0xFF07060D.toInt())
        val image = try {
            assets.open("balle/affiche.jpg").use { BitmapFactory.decodeStream(it) }
        } catch (_: Throwable) { null }
        bloc.addView(ImageView(this).apply {
            if (image != null) setImageBitmap(image)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, FrameLayout.LayoutParams(-1, -1))

        bloc.addView(Button(this).apply {
            text = "COMMENCER"; textSize = 16f
            setTextColor(0xFF2A1C06.toInt())
            setBackgroundColor(0xFFF2C14E.toInt())
            setOnClickListener { racine.removeView(bloc); vue.rejouer() }
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = (36 * resources.displayMetrics.density).toInt()
        })

        racine.addView(bloc, FrameLayout.LayoutParams(-1, -1))
    }

    private fun retour() = Button(this).apply {
        text = "← Partir"; textSize = 12f
        setTextColor(Color.WHITE)
        setBackgroundColor(0xCC150F24.toInt())
        setOnClickListener { finish() }
        layoutParams = FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply {
            topMargin = 46; leftMargin = 18
        }
    }

    private fun finDePartie(titre: String) {
        // la balle au prisonnier : +100 € si on gagne, -70 € sinon
        val gagne = titre.contains("VICTOIRE")
        com.rudy.chambre.Argent.ajouter(this, if (gagne) 100 else -70)
        runOnUiThread {
            // d'abord la video : Rudy, Sophie et Mathis s'ils gagnent,
            // Shanna, Theo et Carlos sinon ; ensuite le choix
            videoDeFin(if (gagne) "balle/fin_victoire.mp4" else "balle/fin_defaite.mp4") {
                if (isFinishing) return@videoDeFin
                AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                    .setTitle(titre)
                    .setPositiveButton("Recommencer") { _, _ -> vue.rejouer() }
                    .setNegativeButton("Partir") { _, _ -> finish() }
                    .setCancelable(false)
                    .show()
            }
        }
    }

    /** Une video plein ecran par-dessus le terrain, puis on continue. */
    private fun videoDeFin(fichier: String, apres: () -> Unit) {
        val bloc = FrameLayout(this)
        bloc.setBackgroundColor(Color.BLACK)
        bloc.isClickable = true                      // le terrain ne recoit plus les doigts
        val ecran = android.view.TextureView(this)
        bloc.addView(ecran, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        var lecteur: android.media.MediaPlayer? = null
        var surface: android.view.Surface? = null
        var fini = false
        fun finir() {
            if (fini) return
            fini = true
            try { lecteur?.release() } catch (_: Throwable) {}
            try { surface?.release() } catch (_: Throwable) {}
            lecteur = null
            racine.removeView(bloc)
            com.rudy.chambre.Ambiance.pauseMusique(false)
            apres()
        }
        bloc.addView(Button(this).apply {
            text = "✕"; textSize = 15f
            setTextColor(Color.WHITE)
            setBackgroundColor(0x66000000)
            setOnClickListener { finir() }
        }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply {
            topMargin = 30; rightMargin = 30
        })
        // l'image garde ses proportions, au centre
        fun ajuster(vw: Int, vh: Int) {
            if (vw <= 0 || vh <= 0 || bloc.width <= 0 || bloc.height <= 0) return
            val k = minOf(bloc.width / vw.toFloat(), bloc.height / vh.toFloat())
            ecran.layoutParams = FrameLayout.LayoutParams((vw * k).toInt(), (vh * k).toInt(), Gravity.CENTER)
        }
        ecran.surfaceTextureListener = object : android.view.TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: android.graphics.SurfaceTexture, w: Int, h: Int) {
                try {
                    val f = assets.openFd(fichier)
                    surface = android.view.Surface(st)
                    lecteur = android.media.MediaPlayer().apply {
                        setDataSource(f.fileDescriptor, f.startOffset, f.length)
                        f.close()
                        setSurface(surface)
                        setOnVideoSizeChangedListener { _, vw, vh -> ajuster(vw, vh) }
                        setOnCompletionListener { finir() }
                        setOnErrorListener { _, _, _ -> finir(); true }
                        prepare()
                        start()
                    }
                } catch (_: Throwable) { finir() }      // pas de video : on passe directement au choix
            }
            override fun onSurfaceTextureSizeChanged(st: android.graphics.SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(st: android.graphics.SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(st: android.graphics.SurfaceTexture) {}
        }
        com.rudy.chambre.Ambiance.pauseMusique(true)
        racine.addView(bloc, FrameLayout.LayoutParams(-1, -1))
    }

    override fun onDestroy() {
        com.rudy.chambre.Ambiance.rendreLaMusique()
        super.onDestroy()
    }
}
