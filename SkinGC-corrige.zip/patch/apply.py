from pathlib import Path
import shutil

root = Path.cwd()
app = root / "Source/Android/app"
payload = Path(__file__).resolve().parent.parent

# Assets et classe du pad.
assets = app / "src/main/assets/skingc"
if assets.exists():
    shutil.rmtree(assets)
shutil.copytree(payload / "skin", assets)
overlay = app / "src/main/java/org/dolphinemu/dolphinemu/overlay/SkinGCOverlay.kt"
shutil.copy2(payload / "patch/SkinGCOverlay.kt", overlay)
shutil.copy2(payload / "patch/SkinWiiGestureView.kt", overlay.parent / "SkinWiiGestureView.kt")
for icon in (payload / "icons").glob("mipmap-*/*.png"):
    shutil.copy2(icon, app / "src/main/res" / icon.parent.name / icon.name)
shutil.copy2(payload / "icons/ic_launcher.xml",
             app / "src/main/res/mipmap-anydpi-v26/ic_launcher.xml")

# Trois axes d'accéléromètre tactiles supplémentaires. Ils permettent aux
# glissements sur l'écran du jeu de devenir de vrais gestes Wiimote.
input_kt = app / "src/main/java/org/dolphinemu/dolphinemu/features/input/model/InputOverrider.kt"
ik = input_kt.read_text()
needle = "        const val CLASSIC_RIGHT_STICK_Y = 55\n"
if "WIIMOTE_ACCEL_X" not in ik:
    assert needle in ik
    ik = ik.replace(needle, needle + '''
        const val WIIMOTE_ACCEL_X = 56
        const val WIIMOTE_ACCEL_Y = 57
        const val WIIMOTE_ACCEL_Z = 58
        const val WIIMOTE_SWING_X = 59
        const val WIIMOTE_SWING_Y = 60
        const val WIIMOTE_SWING_Z = 61
''', 1)
if "WIIMOTE_SWING_X" not in ik:
    ik = ik.replace("        const val WIIMOTE_ACCEL_Z = 58\n", "        const val WIIMOTE_ACCEL_Z = 58\n        const val WIIMOTE_SWING_X = 59\n        const val WIIMOTE_SWING_Y = 60\n        const val WIIMOTE_SWING_Z = 61\n", 1)
input_kt.write_text(ik)

input_h = root / "Source/Core/InputCommon/ControllerInterface/Touch/InputOverrider.h"
ih = input_h.read_text()
needle = "  CLASSIC_RIGHT_STICK_Y = 55,\n"
if "WIIMOTE_ACCEL_X" not in ih:
    assert needle in ih
    ih = ih.replace(needle, needle + '''
  WIIMOTE_ACCEL_X = 56,
  WIIMOTE_ACCEL_Y = 57,
  WIIMOTE_ACCEL_Z = 58,
  WIIMOTE_SWING_X = 59,
  WIIMOTE_SWING_Y = 60,
  WIIMOTE_SWING_Z = 61,
''', 1)
    ih = ih.replace("LAST_WII_CONTROL = CLASSIC_RIGHT_STICK_Y",
                    "LAST_WII_CONTROL = WIIMOTE_SWING_Z")
if "WIIMOTE_SWING_X" not in ih:
    ih = ih.replace("  WIIMOTE_ACCEL_Z = 58,\n", "  WIIMOTE_ACCEL_Z = 58,\n  WIIMOTE_SWING_X = 59,\n  WIIMOTE_SWING_Y = 60,\n  WIIMOTE_SWING_Z = 61,\n", 1)
if "LAST_WII_CONTROL = WIIMOTE_ACCEL_Z" in ih:
    ih = ih.replace("LAST_WII_CONTROL = WIIMOTE_ACCEL_Z", "LAST_WII_CONTROL = WIIMOTE_SWING_Z")
input_h.write_text(ih)

input_cpp = root / "Source/Core/InputCommon/ControllerInterface/Touch/InputOverrider.cpp"
ic = input_cpp.read_text()
needle = '''    {{WiimoteEmu::Wiimote::IR_GROUP, ControllerEmu::ReshapableInput::Y_INPUT_OVERRIDE},
     ControlID::WIIMOTE_IR_Y},
'''
if "ControlID::WIIMOTE_ACCEL_X" not in ic:
    assert needle in ic
    ic = ic.replace(needle, needle + '''    {{WiimoteEmu::Wiimote::ACCELEROMETER_GROUP,
      ControllerEmu::ReshapableInput::X_INPUT_OVERRIDE}, ControlID::WIIMOTE_ACCEL_X},
    {{WiimoteEmu::Wiimote::ACCELEROMETER_GROUP,
      ControllerEmu::ReshapableInput::Y_INPUT_OVERRIDE}, ControlID::WIIMOTE_ACCEL_Y},
    {{WiimoteEmu::Wiimote::ACCELEROMETER_GROUP,
      ControllerEmu::ReshapableInput::Z_INPUT_OVERRIDE}, ControlID::WIIMOTE_ACCEL_Z},
    {{"Swing",
      ControllerEmu::ReshapableInput::X_INPUT_OVERRIDE}, ControlID::WIIMOTE_SWING_X},
    {{"Swing",
      ControllerEmu::ReshapableInput::Y_INPUT_OVERRIDE}, ControlID::WIIMOTE_SWING_Y},
    {{"Swing",
      ControllerEmu::ReshapableInput::Z_INPUT_OVERRIDE}, ControlID::WIIMOTE_SWING_Z},
''', 1)
if "ControlID::WIIMOTE_SWING_X" not in ic:
    accel_map = '''    {{WiimoteEmu::Wiimote::ACCELEROMETER_GROUP,
      ControllerEmu::ReshapableInput::Z_INPUT_OVERRIDE}, ControlID::WIIMOTE_ACCEL_Z},
'''
    assert accel_map in ic
    ic = ic.replace(accel_map, accel_map + '''    {{"Swing",
      ControllerEmu::ReshapableInput::X_INPUT_OVERRIDE}, ControlID::WIIMOTE_SWING_X},
    {{"Swing",
      ControllerEmu::ReshapableInput::Y_INPUT_OVERRIDE}, ControlID::WIIMOTE_SWING_Y},
    {{"Swing",
      ControllerEmu::ReshapableInput::Z_INPUT_OVERRIDE}, ControlID::WIIMOTE_SWING_Z},
''', 1)

# Dolphin annulait l'override IR dès que son état interne changeait entre deux
# images. Les commandes de mouvement restent désormais actives jusqu'au
# ACTION_UP explicite envoyé par SkinGC.
state_needle = '''    const ControlID control = it->second;
    InputState& input_state = state_array[control];
    if (input_state.normal_state != controller_state)
'''
if "const bool persistent_motion" not in ic:
    assert state_needle in ic
    ic = ic.replace(state_needle, '''    const ControlID control = it->second;
    InputState& input_state = state_array[control];
    const bool persistent_motion =
        control == ControlID::WIIMOTE_IR_X || control == ControlID::WIIMOTE_IR_Y ||
        control == ControlID::WIIMOTE_ACCEL_X || control == ControlID::WIIMOTE_ACCEL_Y ||
        control == ControlID::WIIMOTE_ACCEL_Z || control == ControlID::WIIMOTE_SWING_X ||
        control == ControlID::WIIMOTE_SWING_Y || control == ControlID::WIIMOTE_SWING_Z;
    if (!persistent_motion && input_state.normal_state != controller_state)
''', 1)
input_cpp.write_text(ic)

# Le groupe Swing de Dolphin accepte maintenant les axes tactiles injectes.
force_h = root / "Source/Core/InputCommon/ControllerEmu/ControlGroup/Force.h"
fh = force_h.read_text()
if "GetState(const InputOverrideFunction&" not in fh:
    fh = fh.replace("  StateData GetState(bool adjusted = true) const;",
                    "  StateData GetState(bool adjusted = true) const;\n  StateData GetState(const InputOverrideFunction& override_func, bool adjusted = true) const;")
force_h.write_text(fh)

force_cpp = root / "Source/Core/InputCommon/ControllerEmu/ControlGroup/Force.cpp"
fc = force_cpp.read_text()
marker = "ControlState Force::GetSpeed() const"
if "Force::GetState(const InputOverrideFunction&" not in fc:
    assert marker in fc
    impl = '''Force::StateData Force::GetState(const InputOverrideFunction& override_func,
                                             bool adjusted) const
{
  StateData state = GetState(adjusted);
  if (!override_func)
    return state;
  if (const auto value = override_func(name, X_INPUT_OVERRIDE, state.x)) state.x = *value;
  if (const auto value = override_func(name, Y_INPUT_OVERRIDE, state.y)) state.y = *value;
  if (const auto value = override_func(name, Z_INPUT_OVERRIDE, state.z)) state.z = *value;
  return state;
}

'''
    fc = fc.replace(marker, impl + marker, 1)
force_cpp.write_text(fc)

dynamics_h = root / "Source/Core/Core/HW/WiimoteEmu/Dynamics.h"
dh = dynamics_h.read_text()
dh = dh.replace(
    "void EmulateSwing(MotionState* state, ControllerEmu::Force* swing_group, float time_elapsed);",
    "void EmulateSwing(MotionState* state, ControllerEmu::Force* swing_group, float time_elapsed,\n                  const ControllerEmu::InputOverrideFunction& override_func = {});")
dynamics_h.write_text(dh)
dynamics_cpp = root / "Source/Core/Core/HW/WiimoteEmu/Dynamics.cpp"
dc = dynamics_cpp.read_text()
dc = dc.replace(
    "void EmulateSwing(MotionState* state, ControllerEmu::Force* swing_group, float time_elapsed)\n{\n  const auto input_state = swing_group->GetState();",
    "void EmulateSwing(MotionState* state, ControllerEmu::Force* swing_group, float time_elapsed,\n                  const ControllerEmu::InputOverrideFunction& override_func)\n{\n  const auto input_state = swing_group->GetState(override_func);")
# Avec SkinGC, le doigt est un pointeur absolu : aucune inertie artificielle
# ne doit éloigner la main Wii de la position tactile.
point_needle = '''  const auto target_angle = Common::Vec3(pitch_scale * -cursor.y, 0, yaw_scale * -cursor.x);

  // If cursor was hidden, jump to the target angle immediately.
'''
if "SkinGC absolute touch pointer" not in dc:
    assert point_needle in dc
    dc = dc.replace(point_needle, '''  const auto target_angle = Common::Vec3(pitch_scale * -cursor.y, 0, yaw_scale * -cursor.x);

  // SkinGC absolute touch pointer: la main Wii reste exactement sous le doigt.
  if (override_func)
  {
    state->angle = target_angle;
    state->angular_velocity = {};
    return;
  }

  // If cursor was hidden, jump to the target angle immediately.
''', 1)
dynamics_cpp.write_text(dc)
wiimote_cpp = root / "Source/Core/Core/HW/WiimoteEmu/WiimoteEmu.cpp"
wc = wiimote_cpp.read_text()
wc = wc.replace("EmulateSwing(&m_swing_state, m_swing, 1.f / ::Wiimote::UPDATE_FREQ);",
                "EmulateSwing(&m_swing_state, m_swing, 1.f / ::Wiimote::UPDATE_FREQ, m_input_override_function);")
wiimote_cpp.write_text(wc)

# Retour haptique aussi sur les commandes tactiles Dolphin d'origine.
input_overlay = app / "src/main/java/org/dolphinemu/dolphinemu/overlay/InputOverlay.kt"
io = input_overlay.read_text()
field_needle = "    private var overlayPointer: InputOverlayPointer? = null\n"
if "skinGcGestureStarts" not in io:
    assert field_needle in io
    io = io.replace(field_needle, field_needle + '''    private val skinGcGestureStarts = HashMap<Int, android.graphics.PointF>()
''', 1)

pointer_needle = '''        // No button/joystick pressed, safe to move pointer
        if (!pressed && overlayPointer != null) {
'''
if "WIIMOTE_SWING_X, skinDx" not in io:
    assert pointer_needle in io
    pointer_addition = pointer_needle + '''            val skinId = event.getPointerId(pointerIndex)
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN)
                skinGcGestureStarts[skinId] = android.graphics.PointF(event.getX(pointerIndex), event.getY(pointerIndex))
            val skinStart = skinGcGestureStarts[skinId]
            if (skinStart != null) {
                val skinDx = ((event.getX(pointerIndex) - skinStart.x) / width * 2.4f).coerceIn(-1f, 1f)
                val skinDy = ((skinStart.y - event.getY(pointerIndex)) / height * 2.4f).coerceIn(-1f, 1f)
                InputOverrider.setControlState(controllerIndex, ControlId.WIIMOTE_SWING_X, skinDx.toDouble())
                InputOverrider.setControlState(controllerIndex, ControlId.WIIMOTE_SWING_Y, skinDy.toDouble())
                InputOverrider.setControlState(controllerIndex, ControlId.WIIMOTE_SWING_Z, 0.0)
            }
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP) {
                skinGcGestureStarts.remove(skinId)
                postDelayed({
                    for (control in ControlId.WIIMOTE_SWING_X..ControlId.WIIMOTE_SWING_Z)
                        InputOverrider.clearControlState(controllerIndex, control)
                }, 100)
            }
'''
    io = io.replace(pointer_needle, pointer_addition, 1)
haptic_needle = '''        invalidate()

        return true
'''
if "HapticFeedbackConstants.KEYBOARD_TAP" not in io:
    assert haptic_needle in io
    io = io.replace(haptic_needle, '''        if (pressed && (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN))
            performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)

        invalidate()

        return true
''', 1)
input_overlay.write_text(io)

# Un layout unique dans toutes les orientations : la classe calcule elle-même
# le cadre exact et bascule entre portrait/paysage/paysage2.
xml = '''<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/layout_emulation" android:layout_width="match_parent"
    android:layout_height="match_parent" android:keepScreenOn="true">
    <SurfaceView android:id="@+id/surface_emulation"
        android:layout_width="1px" android:layout_height="1px"
        android:focusable="false" android:focusableInTouchMode="false" />
    <org.dolphinemu.dolphinemu.overlay.InputOverlay
        android:id="@+id/surface_input_overlay" android:visibility="gone"
        android:layout_width="match_parent" android:layout_height="match_parent" />
    <org.dolphinemu.dolphinemu.overlay.SkinGCOverlay
        android:id="@+id/skin_gc_overlay" android:layout_width="match_parent"
        android:layout_height="match_parent" android:focusable="true" />
    <Button android:id="@+id/skin_gc_return" android:visibility="gone"
        android:layout_width="56dp" android:layout_height="56dp"
        android:layout_gravity="top|start" android:layout_margin="6dp"
        android:text="🎮" android:textSize="22sp" android:contentDescription="Manette SkinGC" />
    <Button android:id="@+id/done_control_config" android:visibility="gone"
        android:layout_width="wrap_content" android:layout_height="wrap_content" />
</FrameLayout>'''
res = app / "src/main/res"
for d in ("layout", "layout-port", "layout-notouch", "layout-port-notouch"):
    (res / d / "fragment_emulation.xml").write_text(xml)

frag = app / "src/main/java/org/dolphinemu/dolphinemu/fragments/EmulationFragment.kt"
t = frag.read_text()
needle = "        inputOverlay = binding.surfaceInputOverlay\n"
addition = needle + '''
        // SkinGC pilote directement Dolphin et impose au SurfaceView le cadre
        // transparent mesure dans le pad, avant le premier rendu.
        binding.skinGcOverlay.surCadre = { cadre ->
            val p = android.widget.FrameLayout.LayoutParams(
                cadre.width().toInt().coerceAtLeast(1),
                cadre.height().toInt().coerceAtLeast(1)
            )
            p.leftMargin = cadre.left.toInt()
            p.topMargin = cadre.top.toInt()
            val current = surfaceView.layoutParams as? android.widget.FrameLayout.LayoutParams
            if (current == null || current.width != p.width || current.height != p.height ||
                current.leftMargin != p.leftMargin || current.topMargin != p.topMargin)
                surfaceView.layoutParams = p
        }
        binding.skinGcOverlay.surPadOriginal = { original ->
            binding.skinGcOverlay.visibility = if (original) View.GONE else View.VISIBLE
            binding.surfaceInputOverlay.visibility = if (original) View.VISIBLE else View.GONE
            binding.skinGcReturn.visibility = if (original) View.VISIBLE else View.GONE
            if (original) {
                // L'écran des pads Dolphin d'origine est un carré centré,
                // utilisant toute la hauteur du téléphone en paysage.
                val height = binding.layoutEmulation.height.coerceAtLeast(1)
                val gameAspect = org.dolphinemu.dolphinemu.NativeLibrary.GetGameAspectRatio().coerceAtLeast(1f)
                val gameWidth = (height * gameAspect).toInt().coerceAtMost(binding.layoutEmulation.width).coerceAtLeast(1)
                val left = ((binding.layoutEmulation.width - gameWidth) / 2).coerceAtLeast(0)
                val originalParams = android.widget.FrameLayout.LayoutParams(gameWidth, height)
                originalParams.leftMargin = left
                originalParams.topMargin = 0
                val current = surfaceView.layoutParams as? android.widget.FrameLayout.LayoutParams
                if (current == null || current.width != originalParams.width || current.height != originalParams.height ||
                    current.leftMargin != originalParams.leftMargin || current.topMargin != originalParams.topMargin)
                    surfaceView.layoutParams = originalParams
                binding.surfaceInputOverlay.setSurfacePosition(android.graphics.Rect(left, 0, left + gameWidth, height))
                org.dolphinemu.dolphinemu.features.settings.model.BooleanSetting
                    .MAIN_SHOW_INPUT_OVERLAY.setBoolean(
                        org.dolphinemu.dolphinemu.features.settings.model.NativeConfig.LAYER_CURRENT,
                        true
                    )
                binding.surfaceInputOverlay.refreshControls()
                binding.surfaceInputOverlay.refreshOverlayPointer()
            }
        }
        binding.skinGcReturn.setOnClickListener {
            binding.skinGcOverlay.revenirDuPadOriginal()
        }
'''
if "binding.skinGcOverlay.surCadre" not in t:
    assert needle in t
    t = t.replace(needle, addition, 1)
frag.write_text(t)

# Dolphin peut memoriser une orientation forcee dans ses reglages. SkinGC
# suit toujours le capteur pour charger le skin correspondant sans delai.
activity = app / "src/main/java/org/dolphinemu/dolphinemu/activities/EmulationActivity.kt"
a = activity.read_text()
a = a.replace(
    "requestedOrientation = IntSetting.MAIN_EMULATION_ORIENTATION.int",
    "requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR"
)
activity.write_text(a)

# Nom, paquet installable a cote de Dolphin officiel, arm64 uniquement.
gradle = app / "build.gradle.kts"
g = gradle.read_text()
g = g.replace('applicationId = "org.dolphinemu.dolphinemu"', 'applicationId = "com.skingc.dolphin2606"')
g = g.replace('resValue("string", "app_name_suffixed", "Dolphin Debug")',
              'resValue("string", "app_name_suffixed", "SkinGC Dolphin 2606")')
g = g.replace('abiFilters("arm64-v8a", "x86_64")', 'abiFilters("arm64-v8a")')
gradle.write_text(g)

print("SkinGC applique sur Dolphin 2606")
