// SPDX-License-Identifier: GPL-2.0-or-later
package org.dolphinemu.dolphinemu.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.os.Handler
import android.os.Looper
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import org.dolphinemu.dolphinemu.NativeLibrary
import org.dolphinemu.dolphinemu.activities.EmulationActivity
import org.dolphinemu.dolphinemu.features.input.model.InputOverrider
import org.dolphinemu.dolphinemu.features.input.model.InputOverrider.ControlId
import org.dolphinemu.dolphinemu.features.input.model.controlleremu.ControlGroup
import org.dolphinemu.dolphinemu.features.input.model.controlleremu.EmulatedController
import org.dolphinemu.dolphinemu.features.settings.model.FloatSetting
import org.dolphinemu.dolphinemu.features.settings.model.NativeConfig
import org.json.JSONObject
import kotlin.math.hypot
import kotlin.math.max

/** Pads GameCube et Wii SkinGC, branches directement sur le moteur Dolphin officiel. */
class SkinGCOverlay @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs), SensorEventListener {
    private data class Touche(
        val id: String, val type: String, val r: RectF, val repos: Bitmap,
        val appui: Bitmap?, val directions: Map<String, Bitmap>, val course: Float,
        val marge: Float
    )

    var surCadre: ((RectF) -> Unit)? = null
    var surPadOriginal: ((Boolean) -> Unit)? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private var dossier = ""
    private var fond: Bitmap? = null
    private var sw = 1f; private var sh = 1f
    private var ecran = RectF(); private var cadre = RectF()
    private var scale = 1f; private var dx = 0f; private var dy = 0f
    private val touches = ArrayList<Touche>()
    private val doigts = HashMap<Int, Touche>()
    private val appuyees = HashSet<String>()
    private val axes = HashMap<String, PointF>()
    private var variante = context.getSharedPreferences("skingc", 0).getInt("paysage", 0)
    private var varianteWii = context.getSharedPreferences("skingc", 0).getInt("wii", 0)
    private var modeWii = false
    private var familleWii = ""
    private var gestes = false
    private val gestesDebut = HashMap<Int, PointF>()
    private val gestesPosition = HashMap<Int, PointF>()
    private val handler = Handler(Looper.getMainLooper())
    private val capteurs = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometre = capteurs.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
        ?: capteurs.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private var derniereSecousse = 0L

    private val boutons = mapOf(
        "A" to ControlId.GCPAD_A_BUTTON, "B" to ControlId.GCPAD_B_BUTTON,
        "X" to ControlId.GCPAD_X_BUTTON, "Y" to ControlId.GCPAD_Y_BUTTON,
        "Z" to ControlId.GCPAD_Z_BUTTON, "start" to ControlId.GCPAD_START_BUTTON,
        "etoile" to ControlId.GCPAD_START_BUTTON,
        "L" to ControlId.GCPAD_L_DIGITAL, "R" to ControlId.GCPAD_R_DIGITAL
    )

    init {
        setWillNotDraw(false)
        isClickable = true
        context.getSharedPreferences("skingc",0).let { prefs ->
            if (!prefs.getBoolean("ordre_pad_v2",false)) {
                variante=0; varianteWii=0
                prefs.edit().putInt("paysage",0).putInt("wii",0)
                    .putBoolean("ordre_pad_v2",true).apply()
            }
        }
        InputOverrider.registerGameCube(0)
        InputOverrider.registerWii(0)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        accelerometre?.let { capteurs.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    override fun onDetachedFromWindow() {
        relacherTout()
        InputOverrider.unregisterGameCube(0)
        InputOverrider.unregisterWii(0)
        capteurs.unregisterListener(this)
        super.onDetachedFromWindow()
    }

    private fun ouvrir(n: String) = context.assets.open("skingc/$dossier/$n").use {
        BitmapFactory.decodeStream(it)
    }

    private fun charger() {
        val paysage = width >= height
        val suffixe = if (paysage) "paysage" else "portrait"
        val voulu = if (modeWii) {
            // Ordre paysage demandé : Wiimote couchée, Pro, Nunchuk, puis Dolphin.
            val type = when (varianteWii) { 0 -> "seule"; 1 -> "pro"; else -> "nunchuk" }
            "wii_${type}_$suffixe"
        } else if (!paysage) "portrait" else if (variante == 0) "paysage" else "paysage2"
        if (voulu == dossier && fond != null) return
        dossier = voulu; touches.clear(); axes.clear(); appuyees.clear(); doigts.clear()
        val o = context.assets.open("skingc/$dossier/positions.json").bufferedReader().use {
            JSONObject(it.readText())
        }
        familleWii = o.optString("famille", "")
        // Le pointeur tactile doit fonctionner avec chacun des pads Wii.
        gestes = modeWii
        if (modeWii) configurerWiimote(paysage)
        sw = o.getDouble("largeur").toFloat(); sh = o.getDouble("hauteur").toFloat()
        val es = o.getJSONArray("ecran")
        ecran = RectF(es.getDouble(0).toFloat(), es.getDouble(1).toFloat(),
            (es.getDouble(0) + es.getDouble(2)).toFloat(),
            (es.getDouble(1) + es.getDouble(3)).toFloat())
        fond = ouvrir("fond.png")
        val a = o.getJSONArray("elements")
        for (i in 0 until a.length()) {
            val x = a.getJSONObject(i); val im = x.getJSONObject("images")
            val dirs = HashMap<String, Bitmap>()
            im.keys().forEach { k -> if (k != "repos" && k != "appui") {
                val ar = im.getJSONArray(k); if (ar.length() > 0) dirs[k] = ouvrir(ar.getString(ar.length()-1))
            }}
            val press = if (im.has("appui")) im.getJSONArray("appui").let {
                if (it.length() == 0) null else ouvrir(it.getString(it.length()-1))
            } else null
            touches += Touche(x.getString("id"), x.optString("type"),
                RectF(x.getDouble("x").toFloat(), x.getDouble("y").toFloat(),
                    (x.getDouble("x") + x.getDouble("w")).toFloat(),
                    (x.getDouble("y") + x.getDouble("h")).toFloat()),
                ouvrir(im.getString("repos")), press, dirs,
                x.optDouble("course", 24.0).toFloat(), x.optDouble("marge", 0.0).toFloat())
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        charger(); geometrie(w, h)
    }

    private fun geometrie(w: Int = width, h: Int = height) {
        scale = max(w / sw, h / sh) // remplit sans deformation, rogne seulement les bords
        dx = (w - sw * scale) / 2f; dy = (h - sh * scale) / 2f
        cadre.set(dx + ecran.left*scale, dy + ecran.top*scale,
            dx + ecran.right*scale, dy + ecran.bottom*scale)
        surCadre?.invoke(RectF(cadre)); invalidate()
    }

    private fun tel(r: RectF) = RectF(dx+r.left*scale, dy+r.top*scale, dx+r.right*scale, dy+r.bottom*scale)

    override fun onDraw(c: Canvas) {
        if (!modeWii && NativeLibrary.IsGameMetadataValid()) {
            modeWii = NativeLibrary.IsEmulatingWii()
            if (modeWii) {
                // Le chargement d'un jeu recharge les contrôleurs Dolphin :
                // on rebranche donc l'overrider après le démarrage effectif.
                InputOverrider.registerWii(0)
                dossier = ""; charger(); geometrie()
            }
        } else if (!NativeLibrary.IsGameMetadataValid()) {
            postInvalidateDelayed(200)
        }
        charger()
        fond?.let {
            c.save(); if (android.os.Build.VERSION.SDK_INT >= 26) c.clipOutRect(cadre)
            else @Suppress("DEPRECATION") c.clipRect(cadre, Region.Op.DIFFERENCE)
            c.drawBitmap(it, null, RectF(dx,dy,dx+sw*scale,dy+sh*scale),paint); c.restore()
        }
        for (t in touches) {
            val p = axes[t.id]
            val dir = if (p == null || hypot(p.x,p.y) < .25f) "" else direction(p.x,p.y)
            val image = if (dir.isNotEmpty()) t.directions[dir] ?: t.repos
                else if (t.id in appuyees) t.appui ?: t.repos else t.repos
            val r = tel(t.r)
            if ((dir.isNotEmpty() || t.id in appuyees) && image !== t.repos && t.marge > 0f)
                r.inset(-t.marge*scale, -t.marge*scale)
            if ((t.type == "stick") && p != null) r.offset(p.x*t.course*scale,p.y*t.course*scale)
            c.drawBitmap(image,null,r,paint)
        }
    }

    private fun direction(x: Float,y: Float): String {
        val h = y < -.28f; val b = y > .28f; val g=x<-.28f; val d=x>.28f
        return when { h&&g->"hg"; h&&d->"hd"; b&&g->"bg"; b&&d->"bd"; h->"h"; b->"b"; g->"g"; d->"d"; else->"" }
    }

    private fun trouver(x:Float,y:Float)=touches.lastOrNull { tel(it.r).contains(x,y) }
    private fun etat(id:Int,v:Double)=InputOverrider.setControlState(0,id,v)

    private fun boutonWii(id: String): Int? = when (familleWii) {
        "pro" -> when(id) {
            "A"->ControlId.CLASSIC_A_BUTTON; "B"->ControlId.CLASSIC_B_BUTTON
            "X"->ControlId.CLASSIC_X_BUTTON; "Y"->ControlId.CLASSIC_Y_BUTTON
            "ZL"->ControlId.CLASSIC_ZL_BUTTON; "ZR"->ControlId.CLASSIC_ZR_BUTTON
            "L"->ControlId.CLASSIC_L_DIGITAL; "R"->ControlId.CLASSIC_R_DIGITAL
            "start"->ControlId.CLASSIC_PLUS_BUTTON; "select"->ControlId.CLASSIC_MINUS_BUTTON
            else->null
        }
        else -> when(id) {
            "A"->ControlId.WIIMOTE_A_BUTTON; "B"->ControlId.WIIMOTE_B_BUTTON
            "un"->ControlId.WIIMOTE_ONE_BUTTON; "deux"->ControlId.WIIMOTE_TWO_BUTTON
            "start"->ControlId.WIIMOTE_PLUS_BUTTON; "select"->ControlId.WIIMOTE_MINUS_BUTTON
            "C"->ControlId.NUNCHUK_C_BUTTON; "Z"->ControlId.NUNCHUK_Z_BUTTON
            else->null
        }
    }

    private fun configurerWiimote(paysage: Boolean) {
        val wiimote = EmulatedController.getWiimote(0)
        for (i in 0 until wiimote.getGroupCount()) {
            val groupe = wiimote.getGroup(i)
            if (groupe.getGroupType() == ControlGroup.TYPE_ATTACHMENTS) {
                groupe.getAttachmentSetting().setIntValue(
                    when (familleWii) { "nunchuk" -> 1; "pro" -> 2; else -> 0 }
                )
                break
            }
        }
        // La Wiimote seule paysage est tenue sur le côté. Les autres restent droites.
        EmulatedController.getSidewaysWiimoteSetting(0)
            .setBooleanValue(familleWii == "wiimote" && paysage)
    }

    private fun presser(t:Touche,x:Float,y:Float) {
        appuyees += t.id
        performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
        val bouton = if (modeWii) boutonWii(t.id) else boutons[t.id]
        bouton?.let { etat(it,1.0); if(!modeWii && t.id=="L") etat(ControlId.GCPAD_L_ANALOG,1.0); if(!modeWii && t.id=="R") etat(ControlId.GCPAD_R_ANALOG,1.0) }
        when(t.id) {
            "menu" -> (context as? EmulationActivity)?.handleMenuAction(35)
            "jeux", "J", "quit" -> (context as? EmulationActivity)?.handleMenuAction(22)
            "cheat" -> (context as? EmulationActivity)?.onBackPressed()
            "manette" -> {
                val paysage = width >= height
                if (modeWii && paysage && varianteWii == 2) {
                    // Quatrième choix horizontal : pad Dolphin Wiimote + Nunchuk.
                    familleWii="nunchuk"; configurerWiimote(true); surPadOriginal?.invoke(true)
                } else if (!modeWii && paysage && variante == 1) {
                    // Troisième choix horizontal : pad GameCube original Dolphin.
                    surPadOriginal?.invoke(true)
                } else if (modeWii) {
                    varianteWii=(varianteWii+1)%3
                    context.getSharedPreferences("skingc",0).edit().putInt("wii",varianteWii).apply()
                } else {
                    variante=1-variante
                    context.getSharedPreferences("skingc",0).edit().putInt("paysage",variante).apply()
                }
                relacherTout()
                if (visibility == View.VISIBLE) { dossier=""; charger(); geometrie() }
            }
            "ff" -> FloatSetting.MAIN_EMULATION_SPEED.setFloat(NativeConfig.LAYER_CURRENT, 0f)
        }
        if(t.type=="stick" || t.type=="croix") bouger(t,x,y)
        invalidate()
    }

    fun revenirDuPadOriginal() {
        surPadOriginal?.invoke(false)
        if(modeWii) varianteWii=0 else variante=0
        context.getSharedPreferences("skingc",0).edit()
            .putInt("wii",varianteWii).putInt("paysage",variante).apply()
        InputOverrider.registerGameCube(0); InputOverrider.registerWii(0)
        dossier=""; charger(); geometrie()
    }

    private fun bouger(t:Touche,x:Float,y:Float) {
        val r=tel(t.r); var ax=((x-r.centerX())/(r.width()/2)).coerceIn(-1f,1f); var ay=((y-r.centerY())/(r.height()/2)).coerceIn(-1f,1f)
        val d=hypot(ax,ay); if(d>1f){ax/=d;ay/=d}; axes[t.id]=PointF(ax,ay)
        if(t.id=="stick") {
            val ix=if(modeWii) if(familleWii=="pro") ControlId.CLASSIC_LEFT_STICK_X else ControlId.NUNCHUK_STICK_X else ControlId.GCPAD_MAIN_STICK_X
            val iy=if(modeWii) if(familleWii=="pro") ControlId.CLASSIC_LEFT_STICK_Y else ControlId.NUNCHUK_STICK_Y else ControlId.GCPAD_MAIN_STICK_Y
            etat(ix,ax.toDouble());etat(iy,(-ay).toDouble())
        }
        if(t.id=="cstick" || t.id=="stick2") {
            val ix=if(modeWii) ControlId.CLASSIC_RIGHT_STICK_X else ControlId.GCPAD_C_STICK_X
            val iy=if(modeWii) ControlId.CLASSIC_RIGHT_STICK_Y else ControlId.GCPAD_C_STICK_Y
            etat(ix,ax.toDouble());etat(iy,(-ay).toDouble())
        }
        if(t.id=="croix"){
            val base=if(!modeWii) ControlId.GCPAD_DPAD_UP else if(familleWii=="pro") ControlId.CLASSIC_DPAD_UP else ControlId.WIIMOTE_DPAD_UP
            etat(base,if(ay<-.28f)1.0 else 0.0); etat(base+1,if(ay>.28f)1.0 else 0.0)
            etat(base+2,if(ax<-.28f)1.0 else 0.0); etat(base+3,if(ax>.28f)1.0 else 0.0)
        }
    }

    private fun relacher(t:Touche){
        appuyees-=t.id; axes.remove(t.id)
        (if(modeWii) boutonWii(t.id) else boutons[t.id])?.let{etat(it,0.0)}
        when(t.id){"L"->if(!modeWii)etat(ControlId.GCPAD_L_ANALOG,0.0);"R"->if(!modeWii)etat(ControlId.GCPAD_R_ANALOG,0.0);"ff"->FloatSetting.MAIN_EMULATION_SPEED.setFloat(NativeConfig.LAYER_CURRENT,1f)}
        if(t.id=="stick") { if(modeWii){val b=if(familleWii=="pro")ControlId.CLASSIC_LEFT_STICK_X else ControlId.NUNCHUK_STICK_X;etat(b,0.0);etat(b+1,0.0)}else{etat(ControlId.GCPAD_MAIN_STICK_X,0.0);etat(ControlId.GCPAD_MAIN_STICK_Y,0.0)} }
        if(t.id=="cstick"||t.id=="stick2") {val b=if(modeWii)ControlId.CLASSIC_RIGHT_STICK_X else ControlId.GCPAD_C_STICK_X;etat(b,0.0);etat(b+1,0.0)}
        if(t.id=="croix") {val b=if(!modeWii)ControlId.GCPAD_DPAD_UP else if(familleWii=="pro")ControlId.CLASSIC_DPAD_UP else ControlId.WIIMOTE_DPAD_UP;for(i in b..b+3)etat(i,0.0)}
    }
    private fun relacherTout(){doigts.values.toSet().forEach(::relacher);doigts.clear();gestesDebut.clear();gestesPosition.clear()}

    private fun mouvement(id:Int,x:Float,y:Float) {
        val debut=gestesDebut[id]?:return
        gestesPosition[id]=PointF(x,y)
        // Même calcul que le mode FOLLOW officiel de Dolphin : on retire les
        // éventuelles bandes noires pour que le pointeur soit sous le doigt.
        var jeuW=cadre.width(); var jeuH=cadre.height()
        val arSurface=jeuW/jeuH
        val arJeu=NativeLibrary.GetGameAspectRatio().takeIf{it>0f}?:arSurface
        if(arJeu<=arSurface) jeuW=jeuH*arJeu else jeuH=jeuW/arJeu
        val nx=(x-cadre.centerX())/(jeuW*.5f)
        val ny=(y-cadre.centerY())/(jeuH*.5f)
        // Mode FOLLOW : le doigt indique directement la position du pointeur.
        // Dolphin utilise un axe Y inversé pour l'infrarouge.
        etat(ControlId.WIIMOTE_IR_X,nx.toDouble()); etat(ControlId.WIIMOTE_IR_Y,(-ny).toDouble())
        val vx=((x-debut.x)/cadre.width()*24f).coerceIn(-18f,18f)
        val vy=((debut.y-y)/cadre.height()*24f).coerceIn(-18f,18f)
        etat(ControlId.WIIMOTE_ACCEL_X,vx.toDouble()); etat(ControlId.WIIMOTE_ACCEL_Y,vy.toDouble())
        etat(ControlId.WIIMOTE_ACCEL_Z,9.80665)
        val sx=((x-debut.x)/cadre.width()*2.4f).coerceIn(-1f,1f)
        val sy=((debut.y-y)/cadre.height()*2.4f).coerceIn(-1f,1f)
        etat(ControlId.WIIMOTE_SWING_X,sx.toDouble()); etat(ControlId.WIIMOTE_SWING_Y,sy.toDouble())
        etat(ControlId.WIIMOTE_SWING_Z,0.0)
    }

    private fun finirMouvement(id:Int) {
        gestesDebut.remove(id)
        gestesPosition.remove(id)
        handler.postDelayed({
            for(i in ControlId.WIIMOTE_ACCEL_X..ControlId.WIIMOTE_ACCEL_Z) InputOverrider.clearControlState(0,i)
            for(i in ControlId.WIIMOTE_SWING_X..ControlId.WIIMOTE_SWING_Z) InputOverrider.clearControlState(0,i)
        },90)
    }

    fun estModeWii()=modeWii

    private val entretenirPointeur = object:Runnable {
        override fun run() {
            if (gestesPosition.isEmpty()) return
            // La liaison native reste stable. On ne la réenregistre surtout pas
            // pendant le geste : cela pouvait figer le pointeur au premier contact.
            gestesPosition.toMap().forEach { (id,p) -> mouvement(id,p.x,p.y) }
            handler.postDelayed(this,16)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onSensorChanged(event: SensorEvent) {
        // Demande de Rudy : sur la Wiimote seule tenue horizontalement,
        // secouer le téléphone équivaut à secouer la véritable Wiimote.
        if (!modeWii || dossier != "wii_seule_paysage") return
        val x=event.values[0]; val y=event.values[1]; val z=event.values[2]
        val norme=hypot(hypot(x,y),z)
        val lineaire=event.sensor.type==Sensor.TYPE_LINEAR_ACCELERATION
        val force=if(lineaire) norme else kotlin.math.abs(norme-9.80665f)
        if (force < 6.5f) return
        val maintenant=android.os.SystemClock.uptimeMillis()
        if (maintenant-derniereSecousse < 140L) return
        derniereSecousse=maintenant
        etat(ControlId.WIIMOTE_ACCEL_X,x.coerceIn(-20f,20f).toDouble())
        etat(ControlId.WIIMOTE_ACCEL_Y,y.coerceIn(-20f,20f).toDouble())
        val az=if(lineaire) z+9.80665f else z
        etat(ControlId.WIIMOTE_ACCEL_Z,az.coerceIn(-20f,20f).toDouble())
        performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
        handler.postDelayed({
            for(i in ControlId.WIIMOTE_ACCEL_X..ControlId.WIIMOTE_ACCEL_Z)
                InputOverrider.clearControlState(0,i)
        },120)
    }

    @SuppressLint("ClickableViewAccessibility") override fun onTouchEvent(e:MotionEvent):Boolean{
        when(e.actionMasked){
            MotionEvent.ACTION_DOWN,MotionEvent.ACTION_POINTER_DOWN->{parent?.requestDisallowInterceptTouchEvent(true);val i=e.actionIndex;val id=e.getPointerId(i);val x=e.getX(i);val y=e.getY(i);val t=trouver(x,y);if(t!=null){doigts[id]=t;presser(t,x,y)}else if(modeWii&&gestes&&cadre.contains(x,y)){val premier=gestesPosition.isEmpty();gestesDebut[id]=PointF(x,y);gestesPosition[id]=PointF(x,y);InputOverrider.registerWii(0);mouvement(id,x,y);if(premier)handler.post(entretenirPointeur);performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)}}
            MotionEvent.ACTION_MOVE->for(i in 0 until e.pointerCount){val id=e.getPointerId(i);val x=e.getX(i);val y=e.getY(i);val touche=doigts[id];touche?.let{if(it.type=="stick"||it.type=="croix")bouger(it,x,y)};if(modeWii&&touche==null&&cadre.contains(x,y)){if(id !in gestesDebut)gestesDebut[id]=PointF(x,y);gestesPosition[id]=PointF(x,y);mouvement(id,x,y)}}
            MotionEvent.ACTION_UP,MotionEvent.ACTION_POINTER_UP->{val i=e.actionIndex;val id=e.getPointerId(i);doigts.remove(id)?.let(::relacher);finirMouvement(id)}
            MotionEvent.ACTION_CANCEL->relacherTout()
        };invalidate();return true
    }
}
