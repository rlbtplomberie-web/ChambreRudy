// SPDX-License-Identifier: GPL-2.0-or-later
package org.dolphinemu.dolphinemu.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PointF
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import org.dolphinemu.dolphinemu.features.input.model.InputOverrider
import org.dolphinemu.dolphinemu.features.input.model.InputOverrider.ControlId

/** Zone gestuelle posée uniquement sur l'écran du pad Dolphin original Wii. */
class SkinWiiGestureView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    private val debuts=HashMap<Int,PointF>()
    private val positions=HashMap<Int,PointF>()
    private val handler=Handler(Looper.getMainLooper())

    private fun etat(id:Int,v:Double)=InputOverrider.setControlState(0,id,v)

    private fun bouger(id:Int,x:Float,y:Float) {
        val d=debuts[id]?:return
        positions[id]=PointF(x,y)
        val nx=(x/(width/2f)-1f).coerceIn(-1f,1f)
        val ny=(y/(height/2f)-1f).coerceIn(-1f,1f)
        etat(ControlId.WIIMOTE_IR_X,nx.toDouble())
        etat(ControlId.WIIMOTE_IR_Y,(-ny).toDouble())
        val sx=((x-d.x)/width*2.4f).coerceIn(-1f,1f)
        val sy=((d.y-y)/height*2.4f).coerceIn(-1f,1f)
        etat(ControlId.WIIMOTE_SWING_X,sx.toDouble())
        etat(ControlId.WIIMOTE_SWING_Y,sy.toDouble())
        etat(ControlId.WIIMOTE_SWING_Z,0.0)
    }

    private fun finir(id:Int) {
        debuts.remove(id)
        positions.remove(id)
        handler.postDelayed({
            for(i in ControlId.WIIMOTE_SWING_X..ControlId.WIIMOTE_SWING_Z)
                InputOverrider.clearControlState(0,i)
        },100)
    }

    private val entretenir=object:Runnable {
        override fun run() {
            if(positions.isEmpty()) return
            positions.toMap().forEach { (id,p)->bouger(id,p.x,p.y) }
            handler.postDelayed(this,16)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e:MotionEvent):Boolean {
        when(e.actionMasked) {
            MotionEvent.ACTION_DOWN,MotionEvent.ACTION_POINTER_DOWN->{
                val i=e.actionIndex;val id=e.getPointerId(i)
                val premier=positions.isEmpty();InputOverrider.registerWii(0)
                debuts[id]=PointF(e.getX(i),e.getY(i));positions[id]=PointF(e.getX(i),e.getY(i));bouger(id,e.getX(i),e.getY(i))
                if(premier)handler.post(entretenir)
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            }
            MotionEvent.ACTION_MOVE->for(i in 0 until e.pointerCount)
                bouger(e.getPointerId(i),e.getX(i),e.getY(i))
            MotionEvent.ACTION_UP,MotionEvent.ACTION_POINTER_UP->{
                val i=e.actionIndex;finir(e.getPointerId(i))
            }
            MotionEvent.ACTION_CANCEL->{debuts.keys.toList().forEach(::finir)}
        }
        return true
    }
}
