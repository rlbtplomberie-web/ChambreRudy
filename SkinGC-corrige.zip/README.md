# SkinGC – Dolphin officiel 2606

Ce dépôt compile directement Dolphin officiel tag 2606 et y ajoute les trois
habillages SkinGC : portrait, paysage et paysage2. En paysage, le bouton
MANETTE suit cet ordre : petit écran, grand écran, puis pad Dolphin d'origine.

Dans GitHub, ouvrir **Actions**, choisir **Compiler SkinGC Dolphin 2606**, puis
**Run workflow**. Une fois la compilation terminée, télécharger l'artifact
`SkinGC-Dolphin-2606`.

Pour un jeu Wii en paysage, le bouton MANETTE suit cet ordre exact : Wiimote
seule couchée, Pro/nomade, Wiimote + Nunchuk personnalisée, puis Wiimote +
Nunchuk Dolphin d'origine. Depuis le pad d'origine, MANETTE revient au premier
pad personnalisé.

Sur tous les pads Wii, glisser dans l'écran pilote le pointeur et le vrai
groupe Swing de Dolphin : un glissement diagonal produit donc un geste
diagonal. Le quatrième choix paysage affiche la Wiimote + Nunchuk d'origine
de Dolphin. Son bouton MANETTE revient aux pads personnalisés.

Le pointeur Wii est absolu : la main P1 suit directement le doigt, sans inertie
et en tenant compte des bandes noires. Les pads Dolphin d'origine affichent le
jeu au centre, sur toute la hauteur et au bon ratio. Les cadres des pads SkinGC
personnalisés ne sont pas modifiés.

Le changement de pad ne force plus la taille interne de la surface Vulkan.
La résolution native ×2 à ×7 reste gérée par Dolphin, ce qui évite la fermeture
du jeu lors du passage d'un pad à l'autre.

Toutes les touches personnalisées et celles des pads Dolphin produisent un
retour haptique. Le dessin de la croix Wii garde désormais sa taille enfoncée.

Avec la Wiimote seule tenue horizontalement, secouer physiquement le téléphone
déclenche une secousse de Wiimote (par exemple dans les jeux Wario).

L'icône Android utilise la manette GameCube bleue et la Wiimote fournies.

Le premier build compile le moteur C++ complet de Dolphin et peut être long.
