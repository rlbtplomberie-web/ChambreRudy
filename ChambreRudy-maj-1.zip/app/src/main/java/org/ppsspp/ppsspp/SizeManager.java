package org.ppsspp.ppsspp;

import android.content.pm.ActivityInfo;
import android.graphics.Point;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;

public class SizeManager implements SurfaceHolder.Callback {
	private static final String TAG = "PPSSPPSizeManager";

	final PpssppActivity activity;
	SurfaceView surfaceView = null;

	private float densityDpi;
	private float refreshRate;

	private boolean navigationHidden = false;
	private boolean displayUpdatePending = false;

	private final Point desiredSize = new Point();
	private int badOrientationCount = 0;

	// Used to fix a race condition on some Android versions.
	private Surface earlySurface = null;

	private boolean paused = false;

	public SizeManager(final PpssppActivity a) {
		activity = a;
	}

	public void onResume() {
		if (earlySurface != null) {
			Log.i(TAG, "Applying deferred surface");
			activity.notifySurface(earlySurface);
			earlySurface = null;
		}
		paused = false;
	}

	public void onPause() {
		paused = true;
		// Make sure.
		earlySurface = null;
	}

	public void setSurfaceView(SurfaceView view) {
		surfaceView = view;
		if (surfaceView == null)
			return;

		surfaceView.getHolder().addCallback(this);
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		int pixelWidth = holder.getSurfaceFrame().width();
		int pixelHeight = holder.getSurfaceFrame().height();

		// Workaround for terrible bug when locking and unlocking the screen in landscape mode on Nexus 5X.
		// TODO: Look into removing this.
		int requestedOr = activity.getRequestedOrientation();
		boolean requestedPortrait = requestedOr == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT || requestedOr == ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT;
		boolean detectedPortrait = pixelHeight > pixelWidth;
		if (badOrientationCount < 3 && requestedPortrait != detectedPortrait && requestedOr != ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED && requestedOr != ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE && requestedOr != ActivityInfo.SCREEN_ORIENTATION_SENSOR) {
			Log.e(TAG, "Bad orientation detected (w=" + pixelWidth + " h=" + pixelHeight + "! Recreating activity.");
			badOrientationCount++;
			activity.recreate();
			return;
		} else if (requestedPortrait == detectedPortrait) {
			Log.i(TAG, "Correct orientation detected, resetting orientation counter.");
			badOrientationCount = 0;
		} else {
			Log.i(TAG, "Bad orientation detected but ignored");
		}

		Display display = activity.getWindowManager().getDefaultDisplay();

		refreshRate = display.getRefreshRate();

		Log.d(TAG, "Surface created. pixelWidth=" + pixelWidth + ", pixelHeight=" + pixelHeight + " holder: " + holder + " or: " + requestedOr + " " + refreshRate + "Hz");
		NativeApp.setDisplayParameters(pixelWidth, pixelHeight, (int)densityDpi, refreshRate);
		getDesiredBackbufferSize(desiredSize);

		// Note that desiredSize might be 0,0 here - but that's fine when calling setFixedSize! It means auto.
		if (desiredSize.x == 0) {
			Log.d(TAG, "Setting auto surface size (not fixed)");
		} else {
			Log.d(TAG, "Setting fixed surface size " + desiredSize.x + " x " + desiredSize.y);
		}
		holder.setFixedSize(desiredSize.x, desiredSize.y);
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
		Log.v(TAG, "surfaceChanged: isCreating:" + holder.isCreating() + " holder: " + holder);
		if (holder.isCreating() && desiredSize.x > 0 && desiredSize.y > 0) {
			// We have called setFixedSize which will trigger another surfaceChanged after the initial
			// one. This one is the original one, and we don't care about it.
			Log.w(TAG, "holder.isCreating = true, ignoring. width=" + width + " height=" + height + " desWidth=" + desiredSize.x + " desHeight=" + desiredSize.y);

			// TODO: Should we still set earlySurface here, to be sure?
			return;
		}

		Log.i(TAG, "Surface changed. Resolution: " + width + "x" + height + " Format: " + format);
		// The window size might have changed (immersive mode, native fullscreen on some devices)
		NativeApp.backbufferResize(width, height, format);
		updateDisplayMeasurements();

		if (!paused) {
			activity.notifySurface(holder.getSurface());
		} else {
			earlySurface = holder.getSurface();
			Log.i(TAG, "Skipping notifySurface while paused - deferring to resume");
		}
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		activity.notifySurface(null);

		// Autosize the next created surface.
		holder.setSizeFromLayout();
	}

	public void checkDisplayMeasurements() {
		if (displayUpdatePending) {
			return;
		}
		displayUpdatePending = true;

		activity.runOnUiThread(() -> {
			Log.d(TAG, "checkDisplayMeasurements: checking now");
			updateDisplayMeasurements();
		});
	}

	public void updateDisplayMeasurements() {
		displayUpdatePending = false;

		Display display = activity.getWindowManager().getDefaultDisplay();
		// Early in startup, we don't have a view to query. Do our best to get some kind of size
		// that can be used by config default heuristics, and so on.
		DisplayMetrics metrics = new DisplayMetrics();
		if (navigationHidden) {
			display.getRealMetrics(metrics);
		} else {
			display.getMetrics(metrics);
		}

		// Later on, we have the exact pixel size so let's just use it.
		if (surfaceView != null) {
			metrics.widthPixels = surfaceView.getWidth();
			metrics.heightPixels = surfaceView.getHeight();
		}
		densityDpi = metrics.densityDpi;
		refreshRate = display.getRefreshRate();

		NativeApp.setDisplayParameters(metrics.widthPixels, metrics.heightPixels, (int)densityDpi, refreshRate);
	}

	public void setupSystemUiCallback(final View view) {
		view.setOnSystemUiVisibilityChangeListener(visibility -> {
			// Called when the system UI's visibility changes, regardless of
			// whether it's because of our or system actions.
			// We will try to force it to follow our preference but will not stupidly
			// act as if it's visible if it's not.
			navigationHidden = ((visibility & View.SYSTEM_UI_FLAG_HIDE_NAVIGATION) != 0);
			// TODO: Check here if it's the state we want.
			Log.i(TAG, "SystemUiVisibilityChange! visibility=" + visibility + " navigationHidden: " + navigationHidden + " decorView: " + view.getWidth() + "x" + view.getHeight());
			checkDisplayMeasurements();
		});
	}

	public void updateDpi(float dpi) {
		densityDpi = dpi;
	}

	private void getDesiredBackbufferSize(Point sz) {
		NativeApp.computeDesiredBackbufferDimensions();
		sz.x = NativeApp.getDesiredBackbufferWidth();
		sz.y = NativeApp.getDesiredBackbufferHeight();
	}
}
