"""
Transforme le projet Mupen64Plus en morceau de la Chambre.

Son fichier de compilation est écrit pour une application autonome : il déclare
un identifiant d'application et renomme ses APK. Dans notre projet il devient
une bibliothèque, et ces passages n'ont plus de sens — on les retire.
"""
import re
import sys


def retirer_bloc(texte: str, mot: str) -> str:
    """Retire un bloc entier, accolades comprises, partout où le mot apparaît."""
    i = texte.find(mot)
    while i != -1:
        ouvrante = texte.find('{', i)
        if ouvrante == -1:
            break
        profondeur, k = 0, ouvrante
        while k < len(texte):
            if texte[k] == '{':
                profondeur += 1
            elif texte[k] == '}':
                profondeur -= 1
                if profondeur == 0:
                    break
            k += 1
        debut = texte.rfind('\n', 0, i) + 1
        texte = texte[:debut] + texte[k + 1:]
        i = texte.find(mot)
    return texte


def adapter_compilation(chemin: str) -> None:
    t = open(chemin, encoding='utf-8').read()
    t = t.replace('com.android.application', 'com.android.library')
    # tous les reglages qui n'ont de sens que pour une application autonome
    for mot in ('applicationId', 'applicationIdSuffix', 'versionNameSuffix',
                'testApplicationId', 'versionCode', 'versionName'):
        t = re.sub(r'^\s*' + mot + r'\s.*$', '', t, flags=re.M)
        t = re.sub(r'^\s*' + mot + r'\s*=.*$', '', t, flags=re.M)
    for mot in ('applicationVariants', 'splits', 'bundle'):
        t = retirer_bloc(t, mot)
    t = limiter_architecture(t)
    t = aligner_version_minimale(t)
    t = retirer_traduction_des_modules(t)
    open(chemin, 'w', encoding='utf-8').write(t)
    print('fichier de compilation adapte :', chemin)


def poser_espace_de_noms(gradle: str, manifeste: str) -> None:
    """
    Les outils Android récents exigent que chaque morceau déclare son espace de
    noms dans son fichier de compilation, alors que les projets plus anciens le
    mettaient dans le manifeste. On déplace donc l'information.
    """
    m = open(manifeste, encoding='utf-8').read()
    trouve = re.search(r'package\s*=\s*"([^"]+)"', m)
    if not trouve:
        return
    paquet = trouve.group(1)
    m = m.replace(trouve.group(0), '')
    open(manifeste, 'w', encoding='utf-8').write(m)

    t = open(gradle, encoding='utf-8').read()
    if 'namespace' in t:
        return
    # on l'insere juste apres l'ouverture du bloc android
    i = t.find('android')
    j = t.find('{', i)
    if j == -1:
        return
    t = t[:j + 1] + "\n    namespace '" + paquet + "'\n" + t[j + 1:]
    open(gradle, 'w', encoding='utf-8').write(t)
    print('espace de noms pose :', paquet)


def retirer_traduction_des_modules(t: str) -> str:
    """
    Laisser la traduction Java a la seule application.

    Quand un module la declare, Gradle exige que l'application la declare aussi,
    et l'outil qui assemble le code finit par se perdre entre les dossiers de
    chaque module. La Chambre l'active pour tout le monde : les modules n'ont
    pas a la redemander.
    """
    t = re.sub(r'^\s*coreLibraryDesugaringEnabled\s+\w+\s*$', '', t, flags=re.M)
    t = re.sub(r'^\s*coreLibraryDesugaring\s+[\'"][^\'"]*[\'"]\s*$', '', t, flags=re.M)
    return t


def aligner_version_minimale(t: str) -> str:
    """
    Aligner la version minimale d'Android sur celle de la Chambre.

    Ces modules reclament une version plus recente que la notre, et Gradle
    refuse alors de les assembler : « use a compatible library with a minSdk of
    at most 24 ». On ramene donc chacun a 24, comme notre application.
    """
    t = re.sub(r'minSdkVersion\s+\d+', 'minSdkVersion 24', t)
    t = re.sub(r'minSdk\s+\d+', 'minSdk 24', t)
    t = re.sub(r'minSdk\s*=\s*\d+', 'minSdk = 24', t)
    return t


def limiter_architecture(t: str) -> str:
    """
    Ne compiler que pour arm64.

    Ce projet se construit par defaut pour quatre architectures, dont deux qui
    n'existent que sur les ordinateurs. Sur un telephone recent, seule arm64
    sert : on divise ainsi le temps de compilation par deux, et le poids de
    l'application d'autant.
    """
    if "abiFilters 'arm64-v8a'" in t or 'abiFilters "arm64-v8a"' in t:
        return t
    # on remplace toute liste d'architectures existante
    t = re.sub(r"abiFilters\s*[^\n]*", "abiFilters 'arm64-v8a'", t)
    if "abiFilters 'arm64-v8a'" in t:
        return t
    # Sinon on l'ajoute. Attention : ce reglage n'existe que dans defaultConfig.
    # Le poser directement dans android provoque « Could not find method ndk() ».
    i = t.find('defaultConfig')
    if i != -1:
        j = t.find('{', i)
        if j != -1:
            return t[:j + 1] + "\n        ndk { abiFilters 'arm64-v8a' }\n" + t[j + 1:]

    # pas de defaultConfig : on en cree un dans le bloc android
    i = t.find('android')
    if i != -1:
        j = t.find('{', i)
        if j != -1:
            return (t[:j + 1]
                    + "\n    defaultConfig {\n        ndk { abiFilters 'arm64-v8a' }\n    }\n"
                    + t[j + 1:])
    return t


def adapter_manifeste(chemin: str) -> None:
    """
    Son manifeste ne doit plus se comporter en application autonome.

    On lui retire son écran d'accueil, sa classe d'application et les réglages
    généraux qu'il voudrait imposer : c'est le manifeste de la Chambre qui
    décide, sinon la fusion échoue.
    """
    t = open(chemin, encoding='utf-8').read()
    t = t.replace('android.intent.category.LAUNCHER', 'android.intent.category.DEFAULT')

    # les attributs generaux : on les efface, les notres s'appliqueront
    for attribut in ('android:name', 'android:label', 'android:icon',
                     'android:roundIcon', 'android:theme', 'android:allowBackup',
                     'android:supportsRtl', 'android:largeHeap',
                     'android:hardwareAccelerated', 'android:banner',
                     'android:requestLegacyExternalStorage',
                     'android:appComponentFactory', 'android:networkSecurityConfig'):
        t = re.sub(r'(<application\b[^>]*?)\s' + attribut + r'\s*=\s*"[^"]*"',
                   r'\1', t, flags=re.S)
    open(chemin, 'w', encoding='utf-8').write(t)
    print('manifeste adapte :', chemin)


if __name__ == '__main__':
    adapter_compilation(sys.argv[1])
    if len(sys.argv) > 2:
        adapter_manifeste(sys.argv[2])
        poser_espace_de_noms(sys.argv[1], sys.argv[2])
