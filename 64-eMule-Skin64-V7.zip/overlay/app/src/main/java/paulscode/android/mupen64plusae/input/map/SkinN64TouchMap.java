package paulscode.android.mupen64plusae.input.map;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.DisplayMetrics;
import android.view.MotionEvent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import paulscode.android.mupen64plusae.input.AbstractController;
import paulscode.android.mupen64plusae.profile.Profile;

/** M64Plus FZ touch map backed directly by the original SkinN64 artwork. */
public final class SkinN64TouchMap extends VisibleTouchMap {
    public static final String MENU="menu", JEUX="jeux", CHEAT="cheat", QUIT="quit", FF="ff", MANETTE="manette";
    private final Context context;
    private final Map<String, RectF> sourceRects = new HashMap<>();
    private final Map<String, Float> sourceMargins = new HashMap<>();
    private final Map<String, Float> sourceCourses = new HashMap<>();
    private final Map<String, Bitmap[]> sprites = new HashMap<>();
    private final Map<String, Bitmap> directionalSprites = new HashMap<>();
    private final Set<String> pressed = new HashSet<>();
    private final Matrix matrix = new Matrix();
    private String folder = "portrait";
    private Bitmap background;
    private float sourceW, sourceH, factor, offsetX, offsetY;
    private int viewW, viewH;
    private RectF screen = new RectF();
    private boolean analogEnabled = true;
    private boolean nativeMode;
    private String nativeSkinDir;
    private Profile nativeProfile;
    private boolean nativeAnimated;
    private float nativeScale;
    private int nativeAlpha;
    private Bitmap nativeReturnButton;
    private int variant;
    private String dpadDirection;
    private String stickDirection;
    private float stickOffsetX;
    private float stickOffsetY;
    private int stickPointerId = -1;
    private int pressFrame = 1;

    public SkinN64TouchMap(Context context) {
        super(context.getResources());
        this.context = context.getApplicationContext();
        variant = context.getSharedPreferences("skin_n64", Context.MODE_PRIVATE).getInt("variante_paysage", 0);
        if (variant < 0 || variant > 1) variant = 0;
        try { nativeReturnButton=bitmap("skinn64/paysage/manette_0.png"); } catch(Exception ignored) { }
    }

    @Override public void load(Context ignored, String skinDir, Profile profile, boolean animated, float scale, int alpha) {
        nativeSkinDir=skinDir; nativeProfile=profile; nativeAnimated=animated; nativeScale=scale; nativeAlpha=alpha;
        chooseFolder(viewW, viewH);
    }

    private Bitmap bitmap(String path) throws Exception {
        try (InputStream in = context.getAssets().open(path)) { return BitmapFactory.decodeStream(in); }
    }

    private void chooseFolder(int w, int h) {
        if (w <= 0 || h <= 0) return;
        boolean wantNative=w>h && w>0 && variant==2;
        if(wantNative && !nativeMode && nativeSkinDir!=null){
            nativeMode=true;
            super.load(context,nativeSkinDir,nativeProfile,nativeAnimated,nativeScale,nativeAlpha);
            super.resize(w,h,context.getResources().getDisplayMetrics());
            viewW=w;viewH=h;return;
        }
        if(wantNative){nativeMode=true;super.resize(w,h,context.getResources().getDisplayMetrics());viewW=w;viewH=h;return;}
        nativeMode=false;
        String next = (w > h && w > 0) ? (variant == 1 ? "paysage2" : "paysage") : "portrait";
        if (next.equals(folder) && background != null) { compute(w, h); return; }
        folder = next; sourceRects.clear(); sourceMargins.clear(); sourceCourses.clear(); sprites.clear(); directionalSprites.clear(); pressed.clear();
        try {
            background = bitmap("skinn64/" + folder + "/fond.png");
            sourceW = background.getWidth(); sourceH = background.getHeight();
            String raw;
            try (InputStream in = context.getAssets().open("skinn64/" + folder + "/positions.json")) {
                byte[] data = new byte[in.available()]; int n=in.read(data); raw=new String(data,0,n,"UTF-8");
            }
            JSONArray a = new JSONObject(raw).getJSONArray("elements");
            for (int i=0;i<a.length();i++) {
                JSONObject e=a.getJSONObject(i); String id=e.getString("id");
                sourceRects.put(id,new RectF((float)e.getDouble("x"),(float)e.getDouble("y"),
                        (float)(e.getDouble("x")+e.getDouble("w")),(float)(e.getDouble("y")+e.getDouble("h"))));
                sourceMargins.put(id,(float)e.optDouble("marge",0));
                sourceCourses.put(id,(float)e.optDouble("course",0));
                Bitmap[] states=new Bitmap[3];
                for(int state=0;state<3;state++)try { states[state]=bitmap("skinn64/"+folder+"/"+id+"_"+state+".png"); } catch(Exception ignored) { }
                sprites.put(id,states);
                if("croix".equals(id) || "stick".equals(id)) {
                    for(String direction:new String[]{"h","b","g","d","hg","hd","bg","bd"})
                        for(int state=1;state<=2;state++)try {
                            directionalSprites.put(id+"_"+direction+state,bitmap("skinn64/"+folder+"/"+id+"_"+direction+state+".png"));
                        } catch(Exception ignored) { }
                }
            }
            if (folder.equals("portrait")) screen=new RectF(64,174,789,946);
            else if (folder.equals("paysage")) screen=new RectF(380,156,1464,651);
            else if (folder.equals("paysage2")) screen=new RectF(316,15,1528,835);
            else screen=new RectF(0,0,sourceW,sourceH);
        } catch(Exception e) { background=null; }
        compute(w,h);
    }

    private void compute(int w,int h) {
        viewW=w; viewH=h; if(background==null || w<=0 || h<=0)return;
        factor=Math.max(w/sourceW,h/sourceH); // cover: no deformation, edges alone may be cropped
        offsetX=(w-sourceW*factor)/2f; offsetY=(h-sourceH*factor)/2f;
        matrix.reset(); matrix.postScale(factor,factor); matrix.postTranslate(offsetX,offsetY);
    }

    @Override public void resize(int w,int h, DisplayMetrics metrics) { chooseFolder(w,h); }
    @Override public void resize(int w,int h) { chooseFolder(w,h); }

    private RectF mapped(String id) {
        RectF src=sourceRects.get(id); if(src==null)return new RectF();
        RectF out=new RectF(src); matrix.mapRect(out); return out;
    }
    public Rect getGameRect() {
        if(nativeMode)return new Rect(0,0,Math.max(0,viewW),Math.max(0,viewH));
        RectF r=new RectF(screen);
        matrix.mapRect(r);
        int left=Math.max(0,Math.round(r.left));
        int top=Math.max(0,Math.round(r.top));
        int right=Math.min(viewW,Math.round(r.right));
        int bottom=Math.min(viewH,Math.round(r.bottom));
        return new Rect(left,top,Math.max(left,right),Math.max(top,bottom));
    }

    @Override public void drawButtons(Canvas c) {
        if(nativeMode){
            super.drawButtons(c);
            if(nativeReturnButton!=null)c.drawBitmap(nativeReturnButton,null,nativeReturnRect(),null);
            return;
        }
        if(background==null)return;
        int save=c.save(); Rect game=getGameRect();
        if(android.os.Build.VERSION.SDK_INT>=26)c.clipOutRect(game); else c.clipRect(game, android.graphics.Region.Op.DIFFERENCE);
        c.drawBitmap(background,matrix,null);
        for(Map.Entry<String,Bitmap[]> e:sprites.entrySet()) {
            String id=e.getKey(); Bitmap image=null;
            String direction="croix".equals(id)?dpadDirection:("stick".equals(id)?stickDirection:null);
            Bitmap[] states=e.getValue();
            RectF destination=mapped(id);
            if("stick".equals(id))destination.offset(stickOffsetX,stickOffsetY);

            if(direction!=null)image=directionalSprites.get(id+"_"+direction+pressFrame);
            if(image==null && pressed.contains(id) && states!=null)
                image=states[pressFrame]!=null?states[pressFrame]:states[1];
            if(image!=null){
                // The pressed PNG replaces the resting PNG; never stack the two.
                // A very small enlargement compensates for the inset relief in
                // the artwork while preserving the apparent button diameter.
                if(!"croix".equals(id) && !"stick".equals(id))
                    destination.inset(-destination.width()*.035f,-destination.height()*.035f);
                c.drawBitmap(image,null,destination,null);
            } else if(states!=null && states[0]!=null)c.drawBitmap(states[0],null,destination,null);
        }
        c.restoreToCount(save);
    }
    @Override public void drawAnalog(Canvas c) { if(nativeMode)super.drawAnalog(c); }
    @Override public void drawAutoHold(Canvas c) { if(nativeMode)super.drawAutoHold(c); }
    @Override public boolean updateAnalog(float x,float y) { return nativeMode && super.updateAnalog(x,y); }
    @Override public boolean updateAutoHold(boolean p,int i) { return nativeMode && super.updateAutoHold(p,i); }

    private RectF hitRect(String id){
        RectF r=mapped(id); Float margin=sourceMargins.get(id);
        if(margin!=null && margin>0)r.inset(-margin*factor,-margin*factor);
        return r;
    }
    private boolean hit(String id,int x,int y){ return hitRect(id).contains(x,y); }
    private String direction(RectF r,float x,float y){
        float dx=(x-r.centerX())/Math.max(1,r.width()/2),dy=(y-r.centerY())/Math.max(1,r.height()/2);
        if(Math.abs(dx)<.20f && Math.abs(dy)<.20f)return null;
        String vertical=dy<-.30f?"h":(dy>.30f?"b":"");
        String horizontal=dx<-.30f?"g":(dx>.30f?"d":"");
        String combined=vertical+horizontal;
        return combined.isEmpty()?null:combined;
    }
    /** Keep artwork state synchronized with every active finger, including slides and multitouch. */
    public void updatePressed(MotionEvent event){
        if(nativeMode)return;
        pressed.clear(); dpadDirection=null; stickDirection=null; stickOffsetX=0; stickOffsetY=0;
        int action=event.getActionMasked(), lifted=event.getActionIndex();
        pressFrame=action==MotionEvent.ACTION_MOVE?2:1;
        if(action==MotionEvent.ACTION_DOWN || action==MotionEvent.ACTION_POINTER_DOWN){
            int index=event.getActionIndex();
            if(hit("stick",(int)event.getX(index),(int)event.getY(index)))
                stickPointerId=event.getPointerId(index);
        }
        if(action==MotionEvent.ACTION_CANCEL || action==MotionEvent.ACTION_UP)
            stickPointerId=-1;
        else if(action==MotionEvent.ACTION_POINTER_UP && event.getPointerId(lifted)==stickPointerId)
            stickPointerId=-1;
        if(action!=MotionEvent.ACTION_CANCEL && action!=MotionEvent.ACTION_UP)for(int i=0;i<event.getPointerCount();i++){
            if(action==MotionEvent.ACTION_POINTER_UP && i==lifted)continue;
            float x=event.getX(i),y=event.getY(i);
            boolean controlsStick=event.getPointerId(i)==stickPointerId;
            if(controlsStick){
                pressed.add("stick");
                RectF stick=mapped("stick");
                stickDirection=direction(stick,x,y);
                float dx=x-stick.centerX(),dy=y-stick.centerY();
                float distance=(float)Math.sqrt(dx*dx+dy*dy);
                float course=sourceCourses.containsKey("stick")?sourceCourses.get("stick")*factor:0;
                float maximum=Math.max(course*2f,Math.min(stick.width(),stick.height())*.32f);
                if(distance>maximum){dx=dx/distance*maximum;dy=dy/distance*maximum;}
                stickOffsetX=dx; stickOffsetY=dy;
                continue;
            }
            for(String id:sourceRects.keySet())if(!"croix".equals(id) && !"stick".equals(id) && hit(id,(int)x,(int)y))pressed.add(id);
            if(hit("croix",(int)x,(int)y)){pressed.add("croix");dpadDirection=direction(mapped("croix"),x,y);}
        }
    }
    private RectF nativeReturnRect(){float d=context.getResources().getDisplayMetrics().density;return new RectF(12*d,12*d,76*d,76*d);}
    public String functionAt(float x,float y){
        if(nativeMode)return nativeReturnRect().contains(x,y)?MANETTE:null;
        for(String id:new String[]{MENU,JEUX,CHEAT,QUIT,FF,MANETTE})if(hit(id,(int)x,(int)y))return id;
        return null;
    }
    /** Toggle the two requested landscape pads and return to the first. */
    public void cycleVariant(){
        variant=(variant+1)%2;
        context.getSharedPreferences("skin_n64",Context.MODE_PRIVATE)
                .edit().putInt("variante_paysage",variant).apply();
        folder="";
        chooseFolder(viewW,viewH);
    }

    @Override public int getButtonPress(int x,int y) {
        if(nativeMode)return super.getButtonPress(x,y);
        if(hit("A",x,y))return AbstractController.BTN_A;
        if(hit("B",x,y))return AbstractController.BTN_B;
        if(hit("start",x,y) || hit("etoile",x,y))return AbstractController.START;
        if(hit("L",x,y))return AbstractController.BTN_L;
        if(hit("R",x,y))return AbstractController.BTN_R;
        if(hit("Z",x,y))return AbstractController.BTN_Z;
        if(hit("cHaut",x,y))return AbstractController.CPD_U;
        if(hit("cBas",x,y))return AbstractController.CPD_D;
        if(hit("cGauche",x,y))return AbstractController.CPD_L;
        if(hit("cDroite",x,y))return AbstractController.CPD_R;
        RectF d=mapped("croix"); if(d.contains(x,y)){
            float dx=(x-d.centerX())/(d.width()/2),dy=(y-d.centerY())/(d.height()/2);
            if(Math.abs(dx)>.22f && Math.abs(dy)>.22f)return dx>0?(dy>0?DPD_RD:DPD_RU):(dy>0?DPD_LD:DPD_LU);
            if(Math.abs(dx)>Math.abs(dy))return dx>0?AbstractController.DPD_R:AbstractController.DPD_L;
            return dy>0?AbstractController.DPD_D:AbstractController.DPD_U;
        }
        return UNMAPPED;
    }
    @Override public Rect getButtonFrame(String name){ if(nativeMode)return super.getButtonFrame(name);RectF r=mapped(name); return new Rect(Math.round(r.left),Math.round(r.top),Math.round(r.right),Math.round(r.bottom)); }
    @Override public Rect getAnalogFrame(){ if(nativeMode)return super.getAnalogFrame();RectF r=mapped("stick"); return new Rect(Math.round(r.left),Math.round(r.top),Math.round(r.right),Math.round(r.bottom)); }
    @Override public Point getAnalogDisplacement(int x,int y){ if(nativeMode)return super.getAnalogDisplacement(x,y);Rect r=getAnalogFrame(); return analogEnabled?new Point(x-r.centerX(),y-r.centerY()):new Point(); }
    @Override public Point getAnalogDisplacementOriginal(int x,int y){ return nativeMode?super.getAnalogDisplacementOriginal(x,y):getAnalogDisplacement(x,y); }
    @Override public void updateAnalogPosition(int x,int y){ if(nativeMode)super.updateAnalogPosition(x,y); }
    @Override public void resetAnalogPosition(){ if(nativeMode)super.resetAnalogPosition(); }
    @Override public float getAnalogStrength(float displacement){ if(nativeMode)return super.getAnalogStrength(displacement);Rect r=getAnalogFrame(); float radius=Math.max(1,Math.min(r.width(),r.height())*.42f); return Math.max(0,Math.min(1,displacement/radius)); }
    @Override public boolean isInCaptureRange(Point p){ if(nativeMode)return super.isInCaptureRange(p);Rect r=getAnalogFrame(); float radius=Math.max(r.width(),r.height())*.75f; return analogEnabled && p.x*p.x+p.y*p.y<=radius*radius; }
    @Override public void setAnalogEnabled(boolean enabled){ analogEnabled=enabled;if(nativeMode)super.setAnalogEnabled(enabled); }
}
