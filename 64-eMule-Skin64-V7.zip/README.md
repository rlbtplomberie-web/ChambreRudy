# 64 eMule Skin64 V7

Cette version repart de la même révision que l'APK N64-Pad-V8 fonctionnel :
`33bf7021549d7873e976884370fbd1a8e7333bc7`.

Le correctif ne remplace ni GalleryActivity, ni l'écran d'accueil, ni les menus de M64Plus AE.
Il ajoute seulement les quatre pads SkinN64, leurs positions, leurs commandes tactiles, l'icône
SkinN64 et le placement de l'image du jeu dans le cadre noir.

La V5 fait partager exactement la même surface plein écran au rendu du jeu,
au dessin du pad et aux zones tactiles. Elle corrige ainsi le décalage visible
en portrait et en paysage. Le bouton Manette bascule vers les commandes natives
de M64Plus puis revient au même pad Skin64 au second appui, sans quitter le jeu.

Les images d'appui sont maintenant utilisées pour A, B, Start, L, R, Z, les
boutons C, la croix, le joystick et les commandes du haut. Les marges tactiles
du fichier positions.json sont respectées et le bouton etoile du second pad est
relié à Start. La rotation est automatique et traitée dans la même activité afin
de conserver la partie en cours.

La V7 utilise toute la surface physique du Galaxy, y compris derrière la caméra
et les barres Android, tout en conservant les proportions du pad. Le joystick
se déplace sous le doigt selon sa course d'origine. Le dessin au repos reste sous
l'image d'appui afin qu'un bouton ne rétrécisse plus. En paysage, Manette parcourt
les deux pads horizontaux puis revient au premier, sans arrêter la partie.

Pendant un appui, l'image animée remplace désormais le bouton au repos au lieu
de se superposer dessus. Le joystick capture le doigt dès le premier contact et
conserve cette capture jusqu'au relâchement, même lorsque le doigt sort de sa
zone initiale. Sa course visuelle est augmentée pour rendre le mouvement clair.
